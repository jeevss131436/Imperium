# VentureAI — UI Kit

An interactive, high-fidelity recreation of the VentureAI product, built on this
design system's tokens and components. Two surfaces, client-side routed:

- **Landing** (`LandingPage.jsx`) — hero thesis (the wordmark as first statement),
  the scroll-staggered **bento committee index** (six `AgentCell`s on a hairline
  grid; click any to jump into the workspace), and the inverted CTA band.
- **Workspace** (`AppWorkspace.jsx`) — the three-pane deal console: a numbered
  agent index rail, the active agent's intake, and its output. The live
  **Deal Sourcing** agent accepts input and renders a structured profile dossier
  (mock Airbnb result); the other five render the elegant **"deployment pending"**
  empty state with a diagonal hatch.

`Masthead.jsx` is the sticky, blurred editorial header.

## Run

Open `index.html`. It loads React + Babel + Lucide (CDN), the design-system
bundle (`_ds_bundle.js`), the Lucide shim (`assets/icons.js`), and `data.js`
(the agent registry + mock profile, mirroring `ventureai/backend` and
`config/agents.ts`).

## Components used from the system

`AgentCell`, `Button`, `Textarea`, `StatusGlyph`, `Badge`, `ScoreBadge`,
`NavLink` — plus tokens for every color, font, space, and motion value. Icons
are real Lucide glyphs via `<VAIcon name="…" />`.

## Fidelity notes

This recreates the real frontend (`ventureai/frontend/src/components`) closely:
the same hero copy, agent ledger codes, hover-inversion grid, ⌘+Enter submit,
skeleton "reasoning" state, and pending-state copy. The sourcing run is mocked
(1.6s) since the FastAPI backend isn't wired in here.
