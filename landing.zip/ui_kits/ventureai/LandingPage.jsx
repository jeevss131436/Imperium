/* LandingPage — centered editorial thesis, scroll-reveal motion, modern rhythm. */
(function () {
  const { AgentCell, StatusGlyph } = window.VentureAIDesignSystem_c6e9d5;
  const { useState, useRef, useEffect } = React;
  const C = { maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--container-pad)" };
  const center = { display: "flex", flexDirection: "column", alignItems: "center", textAlign: "center" };

  /* Scroll-reveal: fades + rises children into view once, staggered.
     Uses a scroll-position check (IntersectionObserver is unreliable in some
     embedded frames). Honors prefers-reduced-motion by showing immediately. */
  function Reveal({ children, delay = 0, y = 28, as = "div", style = {}, ...rest }) {
    const ref = useRef(null);
    const instant = typeof window !== "undefined" && (
      (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) ||
      document.visibilityState === "hidden"  // backgrounded frames throttle the compositor — show at once
    );
    const [shown, setShown] = useState(instant);

    useEffect(() => {
      if (instant || !ref.current) return;
      const el = ref.current;
      let done = false;
      const reveal = () => {
        if (done) return;
        done = true;
        setShown(true);
        clearInterval(timer);
        clearTimeout(fallback);
        window.removeEventListener("scroll", check);
      };
      const check = () => {
        if (done || !el) return;
        const r = el.getBoundingClientRect();
        const vh = window.innerHeight || document.documentElement.clientHeight || 800;
        if (r.top < vh * 0.88 && r.bottom > 0) reveal();
      };
      // Primary: reveal when scrolled into view (scroll + poll — reliable across frames).
      const timer = setInterval(check, 120);
      window.addEventListener("scroll", check, { passive: true });
      setTimeout(check, 60);
      // Anti-stuck insurance only — long enough not to pre-empt a real scroll reveal.
      const fallback = setTimeout(reveal, 5000);
      return () => { done = true; clearInterval(timer); clearTimeout(fallback); window.removeEventListener("scroll", check); };
    }, [instant]);

    const Tag = as;
    return (
      <Tag ref={ref} style={{
        opacity: shown ? 1 : 0,
        transform: shown ? "none" : `translateY(${y}px)`,
        filter: shown ? "none" : "blur(6px)",
        transition: `opacity 0.9s var(--ease-editorial) ${delay}ms, transform 0.9s var(--ease-editorial) ${delay}ms, filter 0.9s var(--ease-editorial) ${delay}ms`,
        willChange: "opacity, transform",
        ...style,
      }} {...rest}>
        {children}
      </Tag>
    );
  }

  function Hero({ onNavigate }) {
    return (
      <section style={{ position: "relative", borderBottom: "1px solid var(--ink-10)", overflow: "hidden" }}>
        {/* faint centered hairline grid backdrop */}
        <div aria-hidden style={{ position: "absolute", inset: 0, opacity: 0.5, pointerEvents: "none",
          backgroundImage: "linear-gradient(var(--ink-04) 1px, transparent 1px), linear-gradient(90deg, var(--ink-04) 1px, transparent 1px)",
          backgroundSize: "80px 80px",
          maskImage: "radial-gradient(120% 90% at 50% 30%, #000 30%, transparent 75%)",
          WebkitMaskImage: "radial-gradient(120% 90% at 50% 30%, #000 30%, transparent 75%)" }} />
        <div style={{ ...C, ...center, position: "relative", paddingTop: 168, paddingBottom: 120 }}>
          <Reveal as="span" y={0}>
            <span style={{ display: "inline-flex", alignItems: "center", gap: 10, padding: "8px 16px",
              border: "1px solid var(--ink-15)", marginBottom: 48 }}>
              <StatusGlyph available showLabel={false} />
              <span className="va-label-mono">VentureAI — Investment Copilot</span>
            </span>
          </Reveal>

          <Reveal as="h1" delay={80} style={{ margin: 0, maxWidth: 16 + "ch", fontFamily: "var(--font-display)",
            fontWeight: 700, lineHeight: "var(--leading-none)", letterSpacing: "var(--tracking-tightest)",
            fontSize: "var(--text-hero)" }}>
            Venture <span style={{ fontStyle: "italic", fontWeight: 500 }}>conviction,</span> at speed.
          </Reveal>

          <Reveal as="p" delay={180} style={{ margin: "36px 0 0", maxWidth: 760, fontFamily: "var(--font-display)",
            fontSize: "var(--text-display-2)", lineHeight: "var(--leading-snug)", letterSpacing: "var(--tracking-tight)" }}>
            The copilot for high-conviction venture capital — a committee of specialist agents that
            source, diligence, and stress-test a deal before you ever take the meeting.
          </Reveal>

          <Reveal as="p" delay={260} style={{ margin: "24px 0 0", maxWidth: 520, fontFamily: "var(--font-sans)",
            fontSize: "var(--text-base)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>
            Six agents, one pipeline. Each renders its own verdict; you keep every one of them.
          </Reveal>

          <Reveal delay={360} style={{ marginTop: 48, display: "flex", flexWrap: "wrap", gap: 16, justifyContent: "center" }}>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("workspace"); }}
              style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "var(--ink)",
                color: "var(--paper)", padding: "18px 36px", fontFamily: "var(--font-mono)", fontSize: 12,
                textTransform: "uppercase", letterSpacing: "var(--tracking-wider)", textDecoration: "none",
                border: "1px solid var(--ink)", transition: "all var(--dur-base) var(--ease-out)" }}
              onMouseEnter={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--ink)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = "var(--ink)"; e.currentTarget.style.color = "var(--paper)"; }}>
              Enter the workspace
              <VAIcon name="ArrowUpRight" size={16} strokeWidth={1.75} />
            </a>
            <a href="#index" onClick={(e) => { e.preventDefault(); const el = document.getElementById("va-index"); if (el) window.scrollTo({ top: el.offsetTop - 64, behavior: "smooth" }); }}
              style={{ display: "inline-flex", alignItems: "center", gap: 10, background: "transparent",
                color: "var(--ink)", padding: "18px 36px", fontFamily: "var(--font-mono)", fontSize: 12,
                textTransform: "uppercase", letterSpacing: "var(--tracking-wider)", textDecoration: "none",
                border: "1px solid var(--ink-20)", transition: "all var(--dur-base) var(--ease-out)" }}
              onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--ink)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--ink-20)"; }}>
              Meet the committee
            </a>
          </Reveal>

          <Reveal delay={520} style={{ marginTop: 88, display: "flex", flexDirection: "column", alignItems: "center", gap: 12, color: "var(--text-muted)" }}>
            <span style={{ animation: "va-float 2.4s ease-in-out infinite", display: "inline-flex" }}>
              <VAIcon name="ArrowDown" size={18} strokeWidth={1.5} />
            </span>
            <span className="va-label-mono">The index — six agents</span>
          </Reveal>
        </div>
      </section>
    );
  }

  function IndexGrid({ onNavigate }) {
    const spans = ["span 2", "", "", "", "", "span 2"];
    return (
      <section id="va-index" style={{ borderBottom: "1px solid var(--ink-10)" }}>
        <div style={{ ...C, paddingTop: 112, paddingBottom: 112 }}>
          <Reveal style={{ ...center, marginBottom: 64, gap: 20 }}>
            <span className="va-label-mono">The committee</span>
            <h2 style={{ margin: 0, maxWidth: "14ch", fontFamily: "var(--font-display)", fontWeight: 700,
              fontSize: "var(--text-display-1)", letterSpacing: "var(--tracking-tightest)", lineHeight: "var(--leading-tight)" }}>
              Six specialists, one pipeline
            </h2>
            <p style={{ margin: 0, maxWidth: 520, fontFamily: "var(--font-sans)", fontSize: "var(--text-base)",
              lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>
              Each agent is a numbered entry in the deal ledger. The order is the pipeline order — intake to verdict.
            </p>
          </Reveal>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1, background: "var(--ink-10)",
            border: "1px solid var(--ink-10)" }}>
            {window.VA_AGENTS.map((a, i) => (
              <Reveal key={a.id} delay={(i % 3) * 90} y={36} style={{ gridColumn: spans[i] || "auto" }}>
                <div style={{ cursor: "pointer", height: "100%" }} onClick={() => onNavigate("workspace", a.id)}>
                  <AgentCell code={a.code} name={a.name} summary={a.summary} capability={a.capability}
                    available={a.isAvailable} icon={<VAIcon name={a.icon} size={24} strokeWidth={1.4} />}
                    style={{ height: "100%" }} />
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>
    );
  }

  function CTA({ onNavigate }) {
    return (
      <section style={{ background: "var(--ink)", color: "var(--paper)" }}>
        <div style={{ ...C, ...center, paddingTop: 128, paddingBottom: 144, gap: 48 }}>
          <Reveal as="span" y={0}>
            <span className="va-label-mono" style={{ color: "rgba(0,0,0,0.55)" }}>Begin a memo</span>
          </Reveal>
          <Reveal as="h2" delay={100} style={{ margin: 0, maxWidth: "12ch", fontFamily: "var(--font-display)",
            fontWeight: 700, lineHeight: 0.95, letterSpacing: "var(--tracking-tightest)", fontSize: "var(--text-statement)" }}>
            Bring a deal. <span style={{ fontStyle: "italic", fontWeight: 500, color: "rgba(0,0,0,0.78)" }}>Leave with a verdict.</span>
          </Reveal>
          <Reveal delay={220}>
            <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("workspace"); }}
              style={{ display: "inline-flex", alignItems: "center", gap: 12, border: "1px solid rgba(0,0,0,0.3)",
                padding: "20px 36px", fontFamily: "var(--font-mono)", fontSize: 12, textTransform: "uppercase",
                letterSpacing: "var(--tracking-wider)", textDecoration: "none", color: "var(--paper)",
                transition: "all var(--dur-base) var(--ease-out)" }}
              onMouseEnter={(e) => { e.currentTarget.style.background = "var(--paper)"; e.currentTarget.style.color = "var(--ink)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "var(--paper)"; }}>
              Open the workspace
              <VAIcon name="ArrowUpRight" size={16} strokeWidth={1.75} />
            </a>
          </Reveal>
        </div>
      </section>
    );
  }

  function LandingPage({ onNavigate }) {
    return (
      <div>
        <Hero onNavigate={onNavigate} />
        <IndexGrid onNavigate={onNavigate} />
        <CTA onNavigate={onNavigate} />
      </div>
    );
  }

  window.VALandingPage = LandingPage;
})();
