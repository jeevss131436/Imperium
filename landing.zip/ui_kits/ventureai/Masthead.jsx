/* Masthead — sticky editorial header with blur. Uses DS NavLink + Button. */
(function () {
  const { NavLink, Button } = window.VentureAIDesignSystem_c6e9d5;

  function Masthead({ route, onNavigate }) {
    const onWorkspace = route === "workspace";
    return (
      <header
        style={{
          position: "sticky", top: 0, zIndex: 40,
          borderBottom: "1px solid var(--ink-10)",
          background: "var(--masthead-bg)", backdropFilter: "blur(var(--masthead-blur))",
          WebkitBackdropFilter: "blur(var(--masthead-blur))",
        }}
      >
        <div style={{ maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--container-pad)",
          height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <a href="#" onClick={(e) => { e.preventDefault(); onNavigate("landing"); }}
            style={{ display: "flex", alignItems: "baseline", gap: 12, textDecoration: "none", color: "var(--ink)" }}>
            <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 18, letterSpacing: "var(--tracking-tightest)" }}>
              VentureAI
            </span>
            <span className="va-label-mono" style={{ display: "none" }}>Investment Copilot</span>
          </a>
          <nav style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <NavLink href="#" active={!onWorkspace} onClick={(e) => { e.preventDefault(); onNavigate("landing"); }}>Overview</NavLink>
            <NavLink href="#" active={onWorkspace} onClick={(e) => { e.preventDefault(); onNavigate("workspace"); }}>Workspace</NavLink>
            <Button size="sm" style={{ marginLeft: 8 }} onClick={() => onNavigate("workspace")}>
              Launch
              <VAIcon name="ArrowUpRight" size={14} strokeWidth={1.75} />
            </Button>
          </nav>
        </div>
      </header>
    );
  }

  window.VAMasthead = Masthead;
})();
