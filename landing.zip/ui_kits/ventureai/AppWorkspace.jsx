/* AppWorkspace — three-pane deal console: agent index, intake, result/pending. */
(function () {
  const { Button, Textarea, StatusGlyph, Badge, ScoreBadge } = window.VentureAIDesignSystem_c6e9d5;
  const { useState } = React;
  const C = { maxWidth: "var(--container-max)", margin: "0 auto", padding: "0 var(--container-pad)" };
  const labelMono = { fontFamily: "var(--font-mono)", fontSize: "var(--text-2xs)", textTransform: "uppercase",
    letterSpacing: "var(--tracking-ledger)", color: "var(--text-muted)" };

  function AgentIndex({ activeId, onSelect }) {
    return (
      <nav style={{ background: "var(--paper)" }} aria-label="Agent index">
        <p style={{ ...labelMono, padding: "24px 24px 16px" }}>Index</p>
        <ul style={{ listStyle: "none", margin: 0, padding: 0 }}>
          {window.VA_AGENTS.map((a) => {
            const isActive = a.id === activeId;
            return (
              <li key={a.id}>
                <button onClick={() => onSelect(a.id)}
                  style={{ width: "100%", textAlign: "left", display: "flex", alignItems: "center",
                    justifyContent: "space-between", gap: 12, borderTop: "1px solid var(--ink-10)",
                    border: "none", borderTop: "1px solid var(--ink-10)", padding: "20px 24px", cursor: "pointer",
                    background: isActive ? "var(--ink)" : "transparent",
                    color: isActive ? "var(--paper)" : "var(--ink)",
                    transition: "background var(--dur-base) var(--ease-out)" }}
                  onMouseEnter={(e) => { if (!isActive) e.currentTarget.style.background = "var(--ink-04)"; }}
                  onMouseLeave={(e) => { if (!isActive) e.currentTarget.style.background = "transparent"; }}>
                  <span style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                    <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "var(--tracking-wider)",
                      color: isActive ? "var(--ink-60)" : "var(--text-muted)" }}>{a.code}</span>
                    <span style={{ fontFamily: "var(--font-display)", fontSize: 18, fontWeight: 700,
                      lineHeight: 1, letterSpacing: "var(--tracking-tight)" }}>{a.name}</span>
                  </span>
                  {isActive
                    ? <VAIcon name="ArrowRight" size={16} strokeWidth={1.75} />
                    : <StatusGlyph available={a.isAvailable} showLabel={false} />}
                </button>
              </li>
            );
          })}
        </ul>
      </nav>
    );
  }

  function OutputIdle() {
    return (
      <div style={{ minHeight: 220, display: "flex", flexDirection: "column", justifyContent: "center",
        gap: 12, border: "1px dashed var(--ink-15)", padding: 32 }}>
        <p style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-xl)", letterSpacing: "var(--tracking-tight)" }}>Awaiting input</p>
        <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>
          Run the agent to produce a structured profile and a first-pass conviction score.
        </p>
      </div>
    );
  }

  function OutputRunning() {
    return (
      <div style={{ minHeight: 220, display: "flex", flexDirection: "column", gap: 16, border: "1px solid var(--ink-15)", padding: 32 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ display: "inline-flex", animation: "va-spin 1s linear infinite" }}><VAIcon name="Loader2" size={16} strokeWidth={2} /></span>
          <span style={labelMono}>Reasoning</span>
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 12, paddingTop: 8 }}>
          {[100, 82, 64].map((w) => (
            <div key={w} style={{ height: 12, width: w + "%", background: "var(--ink-10)", animation: "va-pulse-dot 1.8s ease-in-out infinite" }} />
          ))}
        </div>
      </div>
    );
  }

  function ProfileCard({ profile }) {
    const meta = [
      { icon: "Layers", label: "Stage", value: profile.stage },
      { icon: "Globe", label: "Industry", value: profile.industry },
      { icon: "MapPin", label: "Location", value: profile.location },
    ];
    return (
      <article style={{ border: "1px solid var(--ink-15)", animation: "va-fade-up 0.5s var(--ease-editorial) both" }}>
        <div style={{ display: "flex", borderBottom: "1px solid var(--ink-15)" }}>
          <div style={{ width: 128, flex: "none", borderRight: "1px solid var(--ink-15)" }}>
            <ScoreBadge score={profile.score} label="Conviction" style={{ height: "100%" }} />
          </div>
          <div style={{ display: "flex", flexDirection: "column", justifyContent: "center", padding: 24 }}>
            <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", fontWeight: 700,
              lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-tight)" }}>{profile.company_name}</h3>
            <p style={{ margin: "4px 0 0", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>{profile.one_liner}</p>
          </div>
        </div>
        <dl style={{ margin: 0, display: "grid", gridTemplateColumns: "repeat(3,1fr)", borderBottom: "1px solid var(--ink-15)" }}>
          {meta.map((m, i) => (
            <div key={m.label} style={{ display: "flex", flexDirection: "column", gap: 8, padding: 16,
              borderRight: i < 2 ? "1px solid var(--ink-15)" : "none" }}>
              <dt style={{ display: "flex", alignItems: "center", gap: 6, fontFamily: "var(--font-mono)", fontSize: 9,
                textTransform: "uppercase", letterSpacing: "var(--tracking-ledger)", color: "var(--text-muted)" }}>
                <VAIcon name={m.icon} size={12} strokeWidth={1.5} />{m.label}
              </dt>
              <dd style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--ink)" }}>{m.value || "—"}</dd>
            </div>
          ))}
        </dl>
        <div style={{ borderBottom: "1px solid var(--ink-15)", padding: 20 }}>
          <p style={{ ...labelMono, margin: "0 0 12px" }}>Founders</p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
            {profile.founders.map((f) => <Badge key={f}>{f}</Badge>)}
          </div>
        </div>
        <div style={{ padding: 20 }}>
          <p style={{ ...labelMono, margin: "0 0 12px" }}>Analyst summary</p>
          <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--ink-90)" }}>{profile.summary}</p>
        </div>
      </article>
    );
  }

  function LiveAgent({ agent }) {
    const [value, setValue] = useState("");
    const [status, setStatus] = useState("idle"); // idle | running | done
    const submit = () => {
      if (!value.trim() || status === "running") return;
      setStatus("running");
      setTimeout(() => setStatus("done"), 1600);
    };
    return (
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <label htmlFor="signal" style={{ ...labelMono, color: "var(--ink-70)" }}>{agent.field.label}</label>
          <Textarea id="signal" value={value} placeholder={agent.field.placeholder}
            disabled={status === "running"} onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submit(); }} />
          <p style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-xs)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>{agent.field.helper}</p>
          <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
            <Button onClick={submit} disabled={!value.trim() || status === "running"} size="lg">
              {status === "running"
                ? <><span style={{ display: "inline-flex", animation: "va-spin 1s linear infinite" }}><VAIcon name="Loader2" size={16} strokeWidth={2} /></span>Sourcing</>
                : <>Run agent<VAIcon name="ArrowRight" size={16} strokeWidth={1.75} /></>}
            </Button>
            <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, textTransform: "uppercase", letterSpacing: "var(--tracking-wider)", color: "var(--text-muted)" }}>⌘ + Enter</span>
          </div>
        </div>
        <div style={{ borderLeft: "1px solid var(--ink-10)", paddingLeft: 40 }}>
          <p style={{ ...labelMono, color: "var(--ink-70)", margin: "0 0 20px" }}>Output — {agent.outputType}</p>
          {status === "idle" && <OutputIdle />}
          {status === "running" && <OutputRunning />}
          {status === "done" && <ProfileCard profile={window.VA_MOCK_PROFILE} />}
        </div>
      </div>
    );
  }

  function PendingState({ agent }) {
    return (
      <div style={{ position: "relative", overflow: "hidden", border: "1px dashed var(--ink-20)",
        animation: "va-fade-up 0.5s var(--ease-editorial) both" }}>
        <div aria-hidden style={{ position: "absolute", inset: 0, opacity: 0.04, pointerEvents: "none",
          backgroundImage: "repeating-linear-gradient(45deg, #FFFFFF 0, #FFFFFF 1px, transparent 1px, transparent 12px)" }} />
        <div style={{ position: "relative", display: "flex", flexDirection: "column", alignItems: "flex-start", gap: 24, padding: 56 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <VAIcon name="Lock" size={20} strokeWidth={1.4} />
            <span style={{ ...labelMono, color: "var(--ink-70)" }}>{agent.code} · Deployment pending</span>
          </div>
          <h3 style={{ margin: 0, maxWidth: 420, fontFamily: "var(--font-display)", fontSize: "var(--text-3xl)",
            fontWeight: 700, lineHeight: "var(--leading-tight)", letterSpacing: "var(--tracking-tightest)" }}>
            {agent.name} isn't online yet.
          </h3>
          <p style={{ margin: 0, maxWidth: 420, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>
            The logic exists in the backend, but this agent still needs its runtime and credentials before it
            can take input. It will surface here automatically the moment it's deployed.
          </p>
          <dl style={{ margin: 0, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 1, width: "100%", maxWidth: 420,
            border: "1px solid var(--ink-10)", background: "var(--ink-10)" }}>
            <div style={{ background: "var(--paper)", padding: 16 }}>
              <dt style={{ ...labelMono, margin: "0 0 6px" }}>Will produce</dt>
              <dd style={{ margin: 0, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", color: "var(--ink)" }}>{agent.capability}</dd>
            </div>
            <div style={{ background: "var(--paper)", padding: 16 }}>
              <dt style={{ ...labelMono, margin: "0 0 6px" }}>Event</dt>
              <dd style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-sm)", color: "var(--ink)" }}>{agent.outputType}</dd>
            </div>
          </dl>
          <Button variant="outline" size="md" disabled><VAIcon name="Lock" size={14} strokeWidth={1.75} />Locked</Button>
        </div>
      </div>
    );
  }

  function AgentPanel({ agent }) {
    return (
      <div style={{ animation: "va-fade-up 0.5s var(--ease-editorial) both" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 16,
          borderBottom: "1px solid var(--ink-10)", paddingBottom: 32 }}>
          <div style={{ display: "flex", alignItems: "flex-start", gap: 20 }}>
            <span style={{ marginTop: 4, display: "inline-flex" }}><VAIcon name={agent.icon} size={32} strokeWidth={1.3} /></span>
            <div>
              <p style={{ margin: 0, fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", letterSpacing: "var(--tracking-wider)", color: "var(--text-muted)" }}>{agent.code} · {agent.role}</p>
              <h2 style={{ margin: "8px 0 0", fontFamily: "var(--font-display)", fontSize: "var(--text-3xl)", fontWeight: 700, letterSpacing: "var(--tracking-tightest)" }}>{agent.name}</h2>
              <p style={{ margin: "12px 0 0", maxWidth: 560, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>{agent.summary}</p>
            </div>
          </div>
          <StatusGlyph available={agent.isAvailable} />
        </div>
        <div style={{ paddingTop: 32 }}>
          {agent.isAvailable ? <LiveAgent agent={agent} /> : <PendingState agent={agent} />}
        </div>
      </div>
    );
  }

  function AppWorkspace({ initialAgentId }) {
    const [activeId, setActiveId] = useState(initialAgentId || window.VA_AGENTS[0].id);
    const active = window.VA_AGENTS.find((a) => a.id === activeId);
    return (
      <div style={{ ...C, paddingTop: 48, paddingBottom: 64 }}>
        <header style={{ marginBottom: 40, display: "flex", alignItems: "flex-end", justifyContent: "space-between",
          gap: 16, borderBottom: "1px solid var(--ink-10)", paddingBottom: 32 }}>
          <div>
            <p style={{ ...labelMono, margin: "0 0 12px" }}>Workspace — Deal Console</p>
            <h1 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-display-1)", fontWeight: 700, letterSpacing: "var(--tracking-tightest)" }}>Run the committee</h1>
          </div>
          <p style={{ margin: 0, maxWidth: 360, fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: "var(--text-muted)" }}>
            Select an agent from the index. Live agents accept input now; the rest are queued for deployment.
          </p>
        </header>
        <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", gap: 1, background: "var(--ink-10)" }}>
          <AgentIndex activeId={activeId} onSelect={setActiveId} />
          <section style={{ background: "var(--paper)", padding: 40 }}>
            <AgentPanel key={active.id} agent={active} />
          </section>
        </div>
      </div>
    );
  }

  window.VAWorkspace = AppWorkspace;
})();
