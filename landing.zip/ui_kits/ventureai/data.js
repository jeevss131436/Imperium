/* VentureAI agent registry + mock data — mirrors ventureai/backend & config/agents.ts. */
window.VA_AGENTS = [
  {
    id: "sourcing", code: "VA-01", name: "Deal Sourcing", role: "Intake & structuring",
    summary: "Turns a name, URL, or raw blurb into a structured startup profile with a first-pass conviction score.",
    capability: "Structured profile + 0–100 score", icon: "Crosshair",
    outputType: "startup_profile", isAvailable: true,
    field: { label: "Company signal", placeholder: "Paste a company name, website, or a few sentences describing the startup…",
      helper: "Anything works — a domain, a one-liner, or a pasted paragraph from a pitch deck." },
  },
  {
    id: "market", code: "VA-02", name: "Market Research", role: "Opportunity sizing",
    summary: "Sizes the TAM, reads the competitive landscape, and renders a verdict on market timing.",
    capability: "TAM, competitors, timing verdict", icon: "Globe2",
    outputType: "market_analysis", isAvailable: false,
  },
  {
    id: "founder", code: "VA-03", name: "Founder Diligence", role: "Team assessment",
    summary: "Evaluates founder–market fit, team completeness, and prior exits — with the red flags left in.",
    capability: "Founder scorecard + flags", icon: "Users",
    outputType: "founder_analysis", isAvailable: false,
  },
  {
    id: "financial", code: "VA-04", name: "Financial Analysis", role: "Model & unit economics",
    summary: "Pressure-tests the revenue model, unit economics, burn, and the path to profitability.",
    capability: "Unit economics + red flags", icon: "LineChart",
    outputType: "financial_analysis", isAvailable: false,
  },
  {
    id: "bear", code: "VA-05", name: "Bear Case", role: "Adversarial review",
    summary: "Argues the other side — failure modes, fragilities, and the reasons this deal could break.",
    capability: "Structured failure modes", icon: "ShieldAlert",
    outputType: "bear_case", isAvailable: false,
  },
  {
    id: "memo", code: "VA-06", name: "Investment Memo", role: "Synthesis & verdict",
    summary: "Synthesizes every agent into one committee-ready memo: a verdict, a score, and the next questions.",
    capability: "PASS · WATCH · INVEST verdict", icon: "FileText",
    outputType: "investment_memo", isAvailable: false,
  },
];

/* Mock sourcing result — the Airbnb profile from ventureai/backend/mock_data.py. */
window.VA_MOCK_PROFILE = {
  company_name: "Airbnb",
  one_liner: "A marketplace for people to list, discover, and book unique accommodations around the world.",
  stage: "Seed", industry: "Travel / Marketplace", location: "San Francisco, CA",
  founders: ["Brian Chesky", "Joe Gebbia", "Nathan Blecharczyk"],
  score: 88,
  summary: "Strong marketplace concept targeting the massive global travel market with unique peer-to-peer supply. Network effects create a durable moat; regulatory headwinds are real but manageable.",
};
