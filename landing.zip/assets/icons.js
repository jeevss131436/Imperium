/**
 * VAIcon — tiny React wrapper around the Lucide UMD build (window.lucide).
 * Lets cards and the UI kit render real Lucide icons (the brand's exclusive
 * icon set) without lucide-react. Load lucide UMD before this file.
 *
 *   <VAIcon name="Crosshair" size={24} strokeWidth={1.4} />
 *
 * `name` is the PascalCase Lucide name (Crosshair, Globe2, Users, LineChart,
 * ShieldAlert, FileText, ArrowUpRight, ArrowRight, ArrowDown, Lock, …).
 */
(function () {
  function resolveNode(name) {
    const L = window.lucide;
    if (!L) return null;
    // UMD exposes icons both as top-level PascalCase exports and under .icons
    return L[name] || (L.icons && L.icons[name]) || null;
  }

  window.VAIcon = function VAIcon(props) {
    var name = props.name;
    var size = props.size == null ? 24 : props.size;
    var strokeWidth = props.strokeWidth == null ? 1.5 : props.strokeWidth;
    var color = props.color || "currentColor";
    var style = props.style;
    var node = resolveNode(name);
    if (!node || !Array.isArray(node[2])) {
      // graceful empty box if the icon name is unknown
      return React.createElement("span", {
        style: Object.assign({ display: "inline-block", width: size, height: size }, style),
      });
    }
    // Lucide IconNode === ["svg", attrs, [ [tag, attrs], ... ]]; children are node[2].
    var children = node[2].map(function (child, i) {
      return React.createElement(child[0], Object.assign({ key: i }, child[1]));
    });
    return React.createElement(
      "svg",
      {
        xmlns: "http://www.w3.org/2000/svg",
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        stroke: color,
        strokeWidth: strokeWidth,
        strokeLinecap: "round",
        strokeLinejoin: "round",
        style: style,
      },
      children
    );
  };
})();
