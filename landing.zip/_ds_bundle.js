/* @ds-bundle: {"format":3,"namespace":"VentureAIDesignSystem_c6e9d5","components":[{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"CardHeader","sourcePath":"components/data-display/Card.jsx"},{"name":"CardTitle","sourcePath":"components/data-display/Card.jsx"},{"name":"CardContent","sourcePath":"components/data-display/Card.jsx"},{"name":"ScoreBadge","sourcePath":"components/data-display/ScoreBadge.jsx"},{"name":"StatusGlyph","sourcePath":"components/data-display/StatusGlyph.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"},{"name":"NavLink","sourcePath":"components/navigation/NavLink.jsx"},{"name":"AgentCell","sourcePath":"components/patterns/AgentCell.jsx"}],"sourceHashes":{"assets/icons.js":"fc85366df6f3","components/data-display/Badge.jsx":"c94139401cc9","components/data-display/Card.jsx":"8e86e2ca29b3","components/data-display/ScoreBadge.jsx":"2840e31dd50b","components/data-display/StatusGlyph.jsx":"d516fce9046f","components/forms/Button.jsx":"9c1fb47401e0","components/forms/Input.jsx":"47cbc6326d9a","components/forms/Textarea.jsx":"6dc07928cb50","components/navigation/NavLink.jsx":"e642c21f03b9","components/patterns/AgentCell.jsx":"76440e75ab64","ui_kits/ventureai/AppWorkspace.jsx":"42a57e66ae6c","ui_kits/ventureai/LandingPage.jsx":"3ff522a9fb2e","ui_kits/ventureai/Masthead.jsx":"0e9d06a39f27","ui_kits/ventureai/data.js":"654d45972113"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.VentureAIDesignSystem_c6e9d5 = window.VentureAIDesignSystem_c6e9d5 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/icons.js
try { (() => {
/**
 * VAIcon — tiny React wrapper around the Lucide UMD build (window.lucide).
 * Lets cards and the UI kit render real Lucide icons (the brand's exclusive
 * icon set) without lucide-react. Load lucide UMD before this file.
 *
 *   <VAIcon name="Crosshair" size={24} strokeWidth={1.4} />
 *
 * `name` is the PascalCase Lucide name (Crosshair, Globe2, Users, LineChart,
 * ShieldAlert, FileText, ArrowUpRight, ArrowRight, ArrowDown, Lock, …).
 */
(function () {
  function resolveNode(name) {
    const L = window.lucide;
    if (!L) return null;
    // UMD exposes icons both as top-level PascalCase exports and under .icons
    return L[name] || L.icons && L.icons[name] || null;
  }
  window.VAIcon = function VAIcon(props) {
    var name = props.name;
    var size = props.size == null ? 24 : props.size;
    var strokeWidth = props.strokeWidth == null ? 1.5 : props.strokeWidth;
    var color = props.color || "currentColor";
    var style = props.style;
    var node = resolveNode(name);
    if (!node || !Array.isArray(node[2])) {
      // graceful empty box if the icon name is unknown
      return React.createElement("span", {
        style: Object.assign({
          display: "inline-block",
          width: size,
          height: size
        }, style)
      });
    }
    // Lucide IconNode === ["svg", attrs, [ [tag, attrs], ... ]]; children are node[2].
    var children = node[2].map(function (child, i) {
      return React.createElement(child[0], Object.assign({
        key: i
      }, child[1]));
    });
    return React.createElement("svg", {
      xmlns: "http://www.w3.org/2000/svg",
      width: size,
      height: size,
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: color,
      strokeWidth: strokeWidth,
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: style
    }, children);
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/icons.js", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Badge — a small mono chip bounded by a hairline (founder tags, metadata
 * pills). Use `solid` for an inverted ink fill, `outline` for the hairline
 * default, `ledger` for an uppercase wide-tracked eyebrow chip.
 */
function Badge({
  variant = "outline",
  className = "",
  style = {},
  children,
  ...props
}) {
  const variants = {
    outline: {
      border: "1px solid var(--ink-20)",
      background: "transparent",
      color: "var(--ink)",
      letterSpacing: "0.04em"
    },
    solid: {
      border: "1px solid var(--ink)",
      background: "var(--ink)",
      color: "var(--paper)",
      letterSpacing: "0.04em"
    },
    ledger: {
      border: "1px solid var(--ink-15)",
      background: "transparent",
      color: "var(--muted-foreground)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wide)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      padding: "4px 12px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      borderRadius: 0,
      whiteSpace: "nowrap",
      ...variants[variant],
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Card — a sharp-cornered container bounded by a hairline. The Swiss grid has
 * no soft edges and no drop shadows. Compose with CardHeader / CardTitle /
 * CardContent, or drop children in directly.
 */
function Card({
  className = "",
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    style: {
      border: "1px solid var(--ink-12)",
      background: "var(--surface-card)",
      color: "var(--text-primary)",
      borderRadius: 0,
      ...style
    }
  }, props), children);
}
function CardHeader({
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      padding: 24,
      ...style
    }
  }, props), children);
}
function CardTitle({
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-xl)",
      fontWeight: "var(--weight-bold)",
      lineHeight: "var(--leading-tight)",
      letterSpacing: "var(--tracking-tight)",
      ...style
    }
  }, props), children);
}
function CardContent({
  style = {},
  children,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      padding: 24,
      paddingTop: 0,
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Card, CardHeader, CardTitle, CardContent });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/ScoreBadge.jsx
try { (() => {
/**
 * ScoreBadge — the conviction score block. A heavy display numeral over a
 * mono ledger caption, on an inverted ink panel. The signature result device.
 */
function ScoreBadge({
  score = 0,
  label = "Conviction",
  className = "",
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: className,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "var(--ink)",
      color: "var(--paper)",
      padding: "24px 28px",
      borderRadius: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "3rem",
      fontWeight: "var(--weight-bold)",
      lineHeight: 1,
      letterSpacing: "var(--tracking-tightest)"
    }
  }, score), /*#__PURE__*/React.createElement("span", {
    style: {
      marginTop: 8,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-3xs)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-ledger)",
      color: "var(--ink-60)"
    }
  }, label));
}
Object.assign(__ds_scope, { ScoreBadge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/ScoreBadge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/StatusGlyph.jsx
try { (() => {
/**
 * StatusGlyph — the signature availability device. Shape + motion only,
 * never color: a filled, pulsing square = live; a hollow square = pending.
 * Drawn in currentColor so it inverts automatically on dark/hover panels.
 */
function StatusGlyph({
  available = false,
  showLabel = true,
  className = "",
  style = {}
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: className,
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": true,
    style: {
      height: 8,
      width: 8,
      background: available ? "currentColor" : "transparent",
      border: available ? "none" : "1px solid currentColor",
      opacity: available ? 1 : 0.5,
      animation: available ? "va-pulse-dot 1.8s ease-in-out infinite" : "none"
    }
  }), showLabel && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-2xs)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-ledger)",
      opacity: 0.7
    }
  }, available ? "Live" : "Pending"));
}
Object.assign(__ds_scope, { StatusGlyph });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/StatusGlyph.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Button — the strict monochrome control. No tints; contrast does the work.
 * Mono uppercase label, wide tracking, sharp corners, 300ms editorial ease.
 */
const SIZES = {
  sm: {
    height: 36,
    padding: "0 16px",
    fontSize: 12
  },
  md: {
    height: 44,
    padding: "0 24px",
    fontSize: 12
  },
  lg: {
    height: 56,
    padding: "0 36px",
    fontSize: 13
  },
  icon: {
    height: 40,
    width: 40,
    padding: 0,
    fontSize: 12
  }
};
function Button({
  variant = "solid",
  size = "md",
  disabled = false,
  className = "",
  style = {},
  children,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const sz = SIZES[size] || SIZES.md;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    whiteSpace: "nowrap",
    fontFamily: "var(--font-mono)",
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-wider)",
    border: "1px solid transparent",
    borderRadius: 0,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    pointerEvents: disabled ? "none" : "auto",
    transition: "all var(--dur-base) var(--ease-out)",
    height: sz.height,
    width: sz.width,
    padding: sz.padding,
    fontSize: sz.fontSize,
    ...variantStyle(variant, hover),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    className: className,
    style: base,
    disabled: disabled,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, props), children);
}
function variantStyle(variant, hover) {
  switch (variant) {
    case "outline":
      return hover ? {
        background: "var(--ink)",
        color: "var(--paper)",
        borderColor: "var(--ink)"
      } : {
        background: "transparent",
        color: "var(--ink)",
        borderColor: "var(--ink-20)"
      };
    case "ghost":
      return {
        background: hover ? "var(--ink-06)" : "transparent",
        color: "var(--ink)",
        borderColor: "transparent"
      };
    case "inverted":
      return {
        background: hover ? "var(--ink-85)" : "var(--paper)",
        color: "var(--ink)"
      };
    case "solid":
    default:
      return {
        background: hover ? "var(--ink-85)" : "var(--ink)",
        color: "var(--paper)"
      };
  }
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Input — a single-line field as a bottom-ruled ledger line.
 * No box; just a hairline underline that brightens to full ink on focus.
 */
function Input({
  className = "",
  style = {},
  disabled = false,
  ...props
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("input", _extends({
    className: className,
    disabled: disabled,
    onFocus: e => {
      setFocus(true);
      props.onFocus?.(e);
    },
    onBlur: e => {
      setFocus(false);
      props.onBlur?.(e);
    },
    style: {
      height: 48,
      width: "100%",
      boxSizing: "border-box",
      border: "none",
      borderBottom: `1px solid ${focus ? "var(--ink)" : "var(--ink-20)"}`,
      background: "transparent",
      padding: "8px 0",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      color: "var(--ink)",
      outline: "none",
      borderRadius: 0,
      opacity: disabled ? 0.4 : 1,
      transition: "border-color var(--dur-base) var(--ease-out)",
      ...style
    }
  }, props));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Textarea — the bordered intake box. Sharp corners, hairline border that
 * brightens to full ink on focus. No resize handle (matches the codebase).
 */
function Textarea({
  className = "",
  style = {},
  disabled = false,
  ...props
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("textarea", _extends({
    className: className,
    disabled: disabled,
    onFocus: e => {
      setFocus(true);
      props.onFocus?.(e);
    },
    onBlur: e => {
      setFocus(false);
      props.onBlur?.(e);
    },
    style: {
      minHeight: 140,
      width: "100%",
      boxSizing: "border-box",
      resize: "none",
      border: `1px solid ${focus ? "var(--ink)" : "var(--ink-20)"}`,
      background: "transparent",
      padding: 16,
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      lineHeight: "var(--leading-relaxed)",
      color: "var(--ink)",
      outline: "none",
      borderRadius: 0,
      opacity: disabled ? 0.4 : 1,
      transition: "border-color var(--dur-base) var(--ease-out)",
      ...style
    }
  }, props));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// components/navigation/NavLink.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * NavLink — a mono uppercase masthead link. Active = full ink; inactive =
 * muted, brightening to ink on hover. Renders an <a>; pass `href`.
 */
function NavLink({
  active = false,
  href = "#",
  className = "",
  style = {},
  children,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    className: className,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-block",
      padding: "8px 12px",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wider)",
      textDecoration: "none",
      color: active ? "var(--ink)" : hover ? "var(--ink)" : "var(--muted-foreground)",
      transition: "color var(--dur-base) var(--ease-out)",
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { NavLink });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/NavLink.jsx", error: String((e && e.message) || e) }); }

// components/patterns/AgentCell.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * AgentCell — the signature bento ledger cell. A numbered committee entry that
 * inverts to ink-on-paper on hover. Used on the landing index grid and as the
 * panel header device. Pass a Lucide icon node via `icon`.
 */
function AgentCell({
  code,
  name,
  summary,
  capability,
  available = false,
  icon = null,
  className = "",
  style = {},
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const fg = hover ? "var(--paper)" : "var(--ink)";
  const muted = hover ? "rgba(0,0,0,0.6)" : "var(--muted-foreground)";
  return /*#__PURE__*/React.createElement("div", _extends({
    className: className,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      position: "relative",
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between",
      gap: 40,
      background: hover ? "var(--ink)" : "var(--paper)",
      color: fg,
      padding: 32,
      minHeight: 280,
      boxSizing: "border-box",
      transition: "background var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out)",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-xs)",
      letterSpacing: "var(--tracking-wider)",
      color: muted,
      transition: "color var(--dur-base) var(--ease-out)"
    }
  }, code), /*#__PURE__*/React.createElement("span", {
    style: {
      color: fg,
      display: "inline-flex"
    }
  }, icon)), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.StatusGlyph, {
    available: available
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-2xl)",
      fontWeight: "var(--weight-bold)",
      letterSpacing: "var(--tracking-tight)"
    }
  }, name), summary && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "12px 0 0",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-sm)",
      lineHeight: "var(--leading-relaxed)",
      color: muted,
      transition: "color var(--dur-base) var(--ease-out)"
    }
  }, summary), capability && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "20px 0 0",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-wide)",
      color: fg,
      transition: "color var(--dur-base) var(--ease-out)"
    }
  }, capability)));
}
Object.assign(__ds_scope, { AgentCell });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/AgentCell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ventureai/AppWorkspace.jsx
try { (() => {
/* AppWorkspace — three-pane deal console: agent index, intake, result/pending. */
(function () {
  const {
    Button,
    Textarea,
    StatusGlyph,
    Badge,
    ScoreBadge
  } = window.VentureAIDesignSystem_c6e9d5;
  const {
    useState
  } = React;
  const C = {
    maxWidth: "var(--container-max)",
    margin: "0 auto",
    padding: "0 var(--container-pad)"
  };
  const labelMono = {
    fontFamily: "var(--font-mono)",
    fontSize: "var(--text-2xs)",
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-ledger)",
    color: "var(--text-muted)"
  };
  function AgentIndex({
    activeId,
    onSelect
  }) {
    return /*#__PURE__*/React.createElement("nav", {
      style: {
        background: "var(--paper)"
      },
      "aria-label": "Agent index"
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        ...labelMono,
        padding: "24px 24px 16px"
      }
    }, "Index"), /*#__PURE__*/React.createElement("ul", {
      style: {
        listStyle: "none",
        margin: 0,
        padding: 0
      }
    }, window.VA_AGENTS.map(a => {
      const isActive = a.id === activeId;
      return /*#__PURE__*/React.createElement("li", {
        key: a.id
      }, /*#__PURE__*/React.createElement("button", {
        onClick: () => onSelect(a.id),
        style: {
          width: "100%",
          textAlign: "left",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          borderTop: "1px solid var(--ink-10)",
          border: "none",
          borderTop: "1px solid var(--ink-10)",
          padding: "20px 24px",
          cursor: "pointer",
          background: isActive ? "var(--ink)" : "transparent",
          color: isActive ? "var(--paper)" : "var(--ink)",
          transition: "background var(--dur-base) var(--ease-out)"
        },
        onMouseEnter: e => {
          if (!isActive) e.currentTarget.style.background = "var(--ink-04)";
        },
        onMouseLeave: e => {
          if (!isActive) e.currentTarget.style.background = "transparent";
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          display: "flex",
          flexDirection: "column",
          gap: 4
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "var(--font-mono)",
          fontSize: 10,
          letterSpacing: "var(--tracking-wider)",
          color: isActive ? "var(--ink-60)" : "var(--text-muted)"
        }
      }, a.code), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "var(--font-display)",
          fontSize: 18,
          fontWeight: 700,
          lineHeight: 1,
          letterSpacing: "var(--tracking-tight)"
        }
      }, a.name)), isActive ? /*#__PURE__*/React.createElement(VAIcon, {
        name: "ArrowRight",
        size: 16,
        strokeWidth: 1.75
      }) : /*#__PURE__*/React.createElement(StatusGlyph, {
        available: a.isAvailable,
        showLabel: false
      })));
    })));
  }
  function OutputIdle() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: 220,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        gap: 12,
        border: "1px dashed var(--ink-15)",
        padding: 32
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-xl)",
        letterSpacing: "var(--tracking-tight)"
      }
    }, "Awaiting input"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, "Run the agent to produce a structured profile and a first-pass conviction score."));
  }
  function OutputRunning() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: 220,
        display: "flex",
        flexDirection: "column",
        gap: 16,
        border: "1px solid var(--ink-15)",
        padding: 32
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        animation: "va-spin 1s linear infinite"
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: "Loader2",
      size: 16,
      strokeWidth: 2
    })), /*#__PURE__*/React.createElement("span", {
      style: labelMono
    }, "Reasoning")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 12,
        paddingTop: 8
      }
    }, [100, 82, 64].map(w => /*#__PURE__*/React.createElement("div", {
      key: w,
      style: {
        height: 12,
        width: w + "%",
        background: "var(--ink-10)",
        animation: "va-pulse-dot 1.8s ease-in-out infinite"
      }
    }))));
  }
  function ProfileCard({
    profile
  }) {
    const meta = [{
      icon: "Layers",
      label: "Stage",
      value: profile.stage
    }, {
      icon: "Globe",
      label: "Industry",
      value: profile.industry
    }, {
      icon: "MapPin",
      label: "Location",
      value: profile.location
    }];
    return /*#__PURE__*/React.createElement("article", {
      style: {
        border: "1px solid var(--ink-15)",
        animation: "va-fade-up 0.5s var(--ease-editorial) both"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        borderBottom: "1px solid var(--ink-15)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 128,
        flex: "none",
        borderRight: "1px solid var(--ink-15)"
      }
    }, /*#__PURE__*/React.createElement(ScoreBadge, {
      score: profile.score,
      label: "Conviction",
      style: {
        height: "100%"
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        padding: 24
      }
    }, /*#__PURE__*/React.createElement("h3", {
      style: {
        margin: 0,
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-2xl)",
        fontWeight: 700,
        lineHeight: "var(--leading-tight)",
        letterSpacing: "var(--tracking-tight)"
      }
    }, profile.company_name), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: "4px 0 0",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, profile.one_liner))), /*#__PURE__*/React.createElement("dl", {
      style: {
        margin: 0,
        display: "grid",
        gridTemplateColumns: "repeat(3,1fr)",
        borderBottom: "1px solid var(--ink-15)"
      }
    }, meta.map((m, i) => /*#__PURE__*/React.createElement("div", {
      key: m.label,
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 8,
        padding: 16,
        borderRight: i < 2 ? "1px solid var(--ink-15)" : "none"
      }
    }, /*#__PURE__*/React.createElement("dt", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontFamily: "var(--font-mono)",
        fontSize: 9,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-ledger)",
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: m.icon,
      size: 12,
      strokeWidth: 1.5
    }), m.label), /*#__PURE__*/React.createElement("dd", {
      style: {
        margin: 0,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        color: "var(--ink)"
      }
    }, m.value || "—")))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderBottom: "1px solid var(--ink-15)",
        padding: 20
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        ...labelMono,
        margin: "0 0 12px"
      }
    }, "Founders"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexWrap: "wrap",
        gap: 8
      }
    }, profile.founders.map(f => /*#__PURE__*/React.createElement(Badge, {
      key: f
    }, f)))), /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 20
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        ...labelMono,
        margin: "0 0 12px"
      }
    }, "Analyst summary"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--ink-90)"
      }
    }, profile.summary)));
  }
  function LiveAgent({
    agent
  }) {
    const [value, setValue] = useState("");
    const [status, setStatus] = useState("idle"); // idle | running | done
    const submit = () => {
      if (!value.trim() || status === "running") return;
      setStatus("running");
      setTimeout(() => setStatus("done"), 1600);
    };
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 40
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("label", {
      htmlFor: "signal",
      style: {
        ...labelMono,
        color: "var(--ink-70)"
      }
    }, agent.field.label), /*#__PURE__*/React.createElement(Textarea, {
      id: "signal",
      value: value,
      placeholder: agent.field.placeholder,
      disabled: status === "running",
      onChange: e => setValue(e.target.value),
      onKeyDown: e => {
        if ((e.metaKey || e.ctrlKey) && e.key === "Enter") submit();
      }
    }), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-xs)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, agent.field.helper), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 16
      }
    }, /*#__PURE__*/React.createElement(Button, {
      onClick: submit,
      disabled: !value.trim() || status === "running",
      size: "lg"
    }, status === "running" ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        animation: "va-spin 1s linear infinite"
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: "Loader2",
      size: 16,
      strokeWidth: 2
    })), "Sourcing") : /*#__PURE__*/React.createElement(React.Fragment, null, "Run agent", /*#__PURE__*/React.createElement(VAIcon, {
      name: "ArrowRight",
      size: 16,
      strokeWidth: 1.75
    }))), /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: 10,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        color: "var(--text-muted)"
      }
    }, "\u2318 + Enter"))), /*#__PURE__*/React.createElement("div", {
      style: {
        borderLeft: "1px solid var(--ink-10)",
        paddingLeft: 40
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        ...labelMono,
        color: "var(--ink-70)",
        margin: "0 0 20px"
      }
    }, "Output \u2014 ", agent.outputType), status === "idle" && /*#__PURE__*/React.createElement(OutputIdle, null), status === "running" && /*#__PURE__*/React.createElement(OutputRunning, null), status === "done" && /*#__PURE__*/React.createElement(ProfileCard, {
      profile: window.VA_MOCK_PROFILE
    })));
  }
  function PendingState({
    agent
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        overflow: "hidden",
        border: "1px dashed var(--ink-20)",
        animation: "va-fade-up 0.5s var(--ease-editorial) both"
      }
    }, /*#__PURE__*/React.createElement("div", {
      "aria-hidden": true,
      style: {
        position: "absolute",
        inset: 0,
        opacity: 0.04,
        pointerEvents: "none",
        backgroundImage: "repeating-linear-gradient(45deg, #FFFFFF 0, #FFFFFF 1px, transparent 1px, transparent 12px)"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        position: "relative",
        display: "flex",
        flexDirection: "column",
        alignItems: "flex-start",
        gap: 24,
        padding: 56
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: "Lock",
      size: 20,
      strokeWidth: 1.4
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        ...labelMono,
        color: "var(--ink-70)"
      }
    }, agent.code, " \xB7 Deployment pending")), /*#__PURE__*/React.createElement("h3", {
      style: {
        margin: 0,
        maxWidth: 420,
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-3xl)",
        fontWeight: 700,
        lineHeight: "var(--leading-tight)",
        letterSpacing: "var(--tracking-tightest)"
      }
    }, agent.name, " isn't online yet."), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        maxWidth: 420,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, "The logic exists in the backend, but this agent still needs its runtime and credentials before it can take input. It will surface here automatically the moment it's deployed."), /*#__PURE__*/React.createElement("dl", {
      style: {
        margin: 0,
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 1,
        width: "100%",
        maxWidth: 420,
        border: "1px solid var(--ink-10)",
        background: "var(--ink-10)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--paper)",
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("dt", {
      style: {
        ...labelMono,
        margin: "0 0 6px"
      }
    }, "Will produce"), /*#__PURE__*/React.createElement("dd", {
      style: {
        margin: 0,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        color: "var(--ink)"
      }
    }, agent.capability)), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--paper)",
        padding: 16
      }
    }, /*#__PURE__*/React.createElement("dt", {
      style: {
        ...labelMono,
        margin: "0 0 6px"
      }
    }, "Event"), /*#__PURE__*/React.createElement("dd", {
      style: {
        margin: 0,
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-sm)",
        color: "var(--ink)"
      }
    }, agent.outputType))), /*#__PURE__*/React.createElement(Button, {
      variant: "outline",
      size: "md",
      disabled: true
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: "Lock",
      size: 14,
      strokeWidth: 1.75
    }), "Locked")));
  }
  function AgentPanel({
    agent
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        animation: "va-fade-up 0.5s var(--ease-editorial) both"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "space-between",
        gap: 16,
        borderBottom: "1px solid var(--ink-10)",
        paddingBottom: 32
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "flex-start",
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        marginTop: 4,
        display: "inline-flex"
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: agent.icon,
      size: 32,
      strokeWidth: 1.3
    })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-xs)",
        letterSpacing: "var(--tracking-wider)",
        color: "var(--text-muted)"
      }
    }, agent.code, " \xB7 ", agent.role), /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: "8px 0 0",
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-3xl)",
        fontWeight: 700,
        letterSpacing: "var(--tracking-tightest)"
      }
    }, agent.name), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: "12px 0 0",
        maxWidth: 560,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, agent.summary))), /*#__PURE__*/React.createElement(StatusGlyph, {
      available: agent.isAvailable
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingTop: 32
      }
    }, agent.isAvailable ? /*#__PURE__*/React.createElement(LiveAgent, {
      agent: agent
    }) : /*#__PURE__*/React.createElement(PendingState, {
      agent: agent
    })));
  }
  function AppWorkspace({
    initialAgentId
  }) {
    const [activeId, setActiveId] = useState(initialAgentId || window.VA_AGENTS[0].id);
    const active = window.VA_AGENTS.find(a => a.id === activeId);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        ...C,
        paddingTop: 48,
        paddingBottom: 64
      }
    }, /*#__PURE__*/React.createElement("header", {
      style: {
        marginBottom: 40,
        display: "flex",
        alignItems: "flex-end",
        justifyContent: "space-between",
        gap: 16,
        borderBottom: "1px solid var(--ink-10)",
        paddingBottom: 32
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
      style: {
        ...labelMono,
        margin: "0 0 12px"
      }
    }, "Workspace \u2014 Deal Console"), /*#__PURE__*/React.createElement("h1", {
      style: {
        margin: 0,
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-display-1)",
        fontWeight: 700,
        letterSpacing: "var(--tracking-tightest)"
      }
    }, "Run the committee")), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        maxWidth: 360,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-sm)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, "Select an agent from the index. Live agents accept input now; the rest are queued for deployment.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "300px 1fr",
        gap: 1,
        background: "var(--ink-10)"
      }
    }, /*#__PURE__*/React.createElement(AgentIndex, {
      activeId: activeId,
      onSelect: setActiveId
    }), /*#__PURE__*/React.createElement("section", {
      style: {
        background: "var(--paper)",
        padding: 40
      }
    }, /*#__PURE__*/React.createElement(AgentPanel, {
      key: active.id,
      agent: active
    }))));
  }
  window.VAWorkspace = AppWorkspace;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ventureai/AppWorkspace.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ventureai/LandingPage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* LandingPage — centered editorial thesis, scroll-reveal motion, modern rhythm. */
(function () {
  const {
    AgentCell,
    StatusGlyph
  } = window.VentureAIDesignSystem_c6e9d5;
  const {
    useState,
    useRef,
    useEffect
  } = React;
  const C = {
    maxWidth: "var(--container-max)",
    margin: "0 auto",
    padding: "0 var(--container-pad)"
  };
  const center = {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    textAlign: "center"
  };

  /* Scroll-reveal: fades + rises children into view once, staggered.
     Uses a scroll-position check (IntersectionObserver is unreliable in some
     embedded frames). Honors prefers-reduced-motion by showing immediately. */
  function Reveal({
    children,
    delay = 0,
    y = 28,
    as = "div",
    style = {},
    ...rest
  }) {
    const ref = useRef(null);
    const instant = typeof window !== "undefined" && (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches || document.visibilityState === "hidden" // backgrounded frames throttle the compositor — show at once
    );
    const [shown, setShown] = useState(instant);
    useEffect(() => {
      if (instant || !ref.current) return;
      const el = ref.current;
      let done = false;
      const reveal = () => {
        if (done) return;
        done = true;
        setShown(true);
        clearInterval(timer);
        clearTimeout(fallback);
        window.removeEventListener("scroll", check);
      };
      const check = () => {
        if (done || !el) return;
        const r = el.getBoundingClientRect();
        const vh = window.innerHeight || document.documentElement.clientHeight || 800;
        if (r.top < vh * 0.88 && r.bottom > 0) reveal();
      };
      // Primary: reveal when scrolled into view (scroll + poll — reliable across frames).
      const timer = setInterval(check, 120);
      window.addEventListener("scroll", check, {
        passive: true
      });
      setTimeout(check, 60);
      // Anti-stuck insurance only — long enough not to pre-empt a real scroll reveal.
      const fallback = setTimeout(reveal, 5000);
      return () => {
        done = true;
        clearInterval(timer);
        clearTimeout(fallback);
        window.removeEventListener("scroll", check);
      };
    }, [instant]);
    const Tag = as;
    return /*#__PURE__*/React.createElement(Tag, _extends({
      ref: ref,
      style: {
        opacity: shown ? 1 : 0,
        transform: shown ? "none" : `translateY(${y}px)`,
        filter: shown ? "none" : "blur(6px)",
        transition: `opacity 0.9s var(--ease-editorial) ${delay}ms, transform 0.9s var(--ease-editorial) ${delay}ms, filter 0.9s var(--ease-editorial) ${delay}ms`,
        willChange: "opacity, transform",
        ...style
      }
    }, rest), children);
  }
  function Hero({
    onNavigate
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        position: "relative",
        borderBottom: "1px solid var(--ink-10)",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      "aria-hidden": true,
      style: {
        position: "absolute",
        inset: 0,
        opacity: 0.5,
        pointerEvents: "none",
        backgroundImage: "linear-gradient(var(--ink-04) 1px, transparent 1px), linear-gradient(90deg, var(--ink-04) 1px, transparent 1px)",
        backgroundSize: "80px 80px",
        maskImage: "radial-gradient(120% 90% at 50% 30%, #000 30%, transparent 75%)",
        WebkitMaskImage: "radial-gradient(120% 90% at 50% 30%, #000 30%, transparent 75%)"
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        ...C,
        ...center,
        position: "relative",
        paddingTop: 168,
        paddingBottom: 120
      }
    }, /*#__PURE__*/React.createElement(Reveal, {
      as: "span",
      y: 0
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        padding: "8px 16px",
        border: "1px solid var(--ink-15)",
        marginBottom: 48
      }
    }, /*#__PURE__*/React.createElement(StatusGlyph, {
      available: true,
      showLabel: false
    }), /*#__PURE__*/React.createElement("span", {
      className: "va-label-mono"
    }, "VentureAI \u2014 Investment Copilot"))), /*#__PURE__*/React.createElement(Reveal, {
      as: "h1",
      delay: 80,
      style: {
        margin: 0,
        maxWidth: 16 + "ch",
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        lineHeight: "var(--leading-none)",
        letterSpacing: "var(--tracking-tightest)",
        fontSize: "var(--text-hero)"
      }
    }, "Venture ", /*#__PURE__*/React.createElement("span", {
      style: {
        fontStyle: "italic",
        fontWeight: 500
      }
    }, "conviction,"), " at speed."), /*#__PURE__*/React.createElement(Reveal, {
      as: "p",
      delay: 180,
      style: {
        margin: "36px 0 0",
        maxWidth: 760,
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-display-2)",
        lineHeight: "var(--leading-snug)",
        letterSpacing: "var(--tracking-tight)"
      }
    }, "The copilot for high-conviction venture capital \u2014 a committee of specialist agents that source, diligence, and stress-test a deal before you ever take the meeting."), /*#__PURE__*/React.createElement(Reveal, {
      as: "p",
      delay: 260,
      style: {
        margin: "24px 0 0",
        maxWidth: 520,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, "Six agents, one pipeline. Each renders its own verdict; you keep every one of them."), /*#__PURE__*/React.createElement(Reveal, {
      delay: 360,
      style: {
        marginTop: 48,
        display: "flex",
        flexWrap: "wrap",
        gap: 16,
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNavigate("workspace");
      },
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        background: "var(--ink)",
        color: "var(--paper)",
        padding: "18px 36px",
        fontFamily: "var(--font-mono)",
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        textDecoration: "none",
        border: "1px solid var(--ink)",
        transition: "all var(--dur-base) var(--ease-out)"
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = "transparent";
        e.currentTarget.style.color = "var(--ink)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = "var(--ink)";
        e.currentTarget.style.color = "var(--paper)";
      }
    }, "Enter the workspace", /*#__PURE__*/React.createElement(VAIcon, {
      name: "ArrowUpRight",
      size: 16,
      strokeWidth: 1.75
    })), /*#__PURE__*/React.createElement("a", {
      href: "#index",
      onClick: e => {
        e.preventDefault();
        const el = document.getElementById("va-index");
        if (el) window.scrollTo({
          top: el.offsetTop - 64,
          behavior: "smooth"
        });
      },
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 10,
        background: "transparent",
        color: "var(--ink)",
        padding: "18px 36px",
        fontFamily: "var(--font-mono)",
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        textDecoration: "none",
        border: "1px solid var(--ink-20)",
        transition: "all var(--dur-base) var(--ease-out)"
      },
      onMouseEnter: e => {
        e.currentTarget.style.borderColor = "var(--ink)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.borderColor = "var(--ink-20)";
      }
    }, "Meet the committee")), /*#__PURE__*/React.createElement(Reveal, {
      delay: 520,
      style: {
        marginTop: 88,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 12,
        color: "var(--text-muted)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        animation: "va-float 2.4s ease-in-out infinite",
        display: "inline-flex"
      }
    }, /*#__PURE__*/React.createElement(VAIcon, {
      name: "ArrowDown",
      size: 18,
      strokeWidth: 1.5
    })), /*#__PURE__*/React.createElement("span", {
      className: "va-label-mono"
    }, "The index \u2014 six agents"))));
  }
  function IndexGrid({
    onNavigate
  }) {
    const spans = ["span 2", "", "", "", "", "span 2"];
    return /*#__PURE__*/React.createElement("section", {
      id: "va-index",
      style: {
        borderBottom: "1px solid var(--ink-10)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        ...C,
        paddingTop: 112,
        paddingBottom: 112
      }
    }, /*#__PURE__*/React.createElement(Reveal, {
      style: {
        ...center,
        marginBottom: 64,
        gap: 20
      }
    }, /*#__PURE__*/React.createElement("span", {
      className: "va-label-mono"
    }, "The committee"), /*#__PURE__*/React.createElement("h2", {
      style: {
        margin: 0,
        maxWidth: "14ch",
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: "var(--text-display-1)",
        letterSpacing: "var(--tracking-tightest)",
        lineHeight: "var(--leading-tight)"
      }
    }, "Six specialists, one pipeline"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        maxWidth: 520,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-muted)"
      }
    }, "Each agent is a numbered entry in the deal ledger. The order is the pipeline order \u2014 intake to verdict.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 1,
        background: "var(--ink-10)",
        border: "1px solid var(--ink-10)"
      }
    }, window.VA_AGENTS.map((a, i) => /*#__PURE__*/React.createElement(Reveal, {
      key: a.id,
      delay: i % 3 * 90,
      y: 36,
      style: {
        gridColumn: spans[i] || "auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        cursor: "pointer",
        height: "100%"
      },
      onClick: () => onNavigate("workspace", a.id)
    }, /*#__PURE__*/React.createElement(AgentCell, {
      code: a.code,
      name: a.name,
      summary: a.summary,
      capability: a.capability,
      available: a.isAvailable,
      icon: /*#__PURE__*/React.createElement(VAIcon, {
        name: a.icon,
        size: 24,
        strokeWidth: 1.4
      }),
      style: {
        height: "100%"
      }
    })))))));
  }
  function CTA({
    onNavigate
  }) {
    return /*#__PURE__*/React.createElement("section", {
      style: {
        background: "var(--ink)",
        color: "var(--paper)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        ...C,
        ...center,
        paddingTop: 128,
        paddingBottom: 144,
        gap: 48
      }
    }, /*#__PURE__*/React.createElement(Reveal, {
      as: "span",
      y: 0
    }, /*#__PURE__*/React.createElement("span", {
      className: "va-label-mono",
      style: {
        color: "rgba(0,0,0,0.55)"
      }
    }, "Begin a memo")), /*#__PURE__*/React.createElement(Reveal, {
      as: "h2",
      delay: 100,
      style: {
        margin: 0,
        maxWidth: "12ch",
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        lineHeight: 0.95,
        letterSpacing: "var(--tracking-tightest)",
        fontSize: "var(--text-statement)"
      }
    }, "Bring a deal. ", /*#__PURE__*/React.createElement("span", {
      style: {
        fontStyle: "italic",
        fontWeight: 500,
        color: "rgba(0,0,0,0.78)"
      }
    }, "Leave with a verdict.")), /*#__PURE__*/React.createElement(Reveal, {
      delay: 220
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNavigate("workspace");
      },
      style: {
        display: "inline-flex",
        alignItems: "center",
        gap: 12,
        border: "1px solid rgba(0,0,0,0.3)",
        padding: "20px 36px",
        fontFamily: "var(--font-mono)",
        fontSize: 12,
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        textDecoration: "none",
        color: "var(--paper)",
        transition: "all var(--dur-base) var(--ease-out)"
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = "var(--paper)";
        e.currentTarget.style.color = "var(--ink)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = "transparent";
        e.currentTarget.style.color = "var(--paper)";
      }
    }, "Open the workspace", /*#__PURE__*/React.createElement(VAIcon, {
      name: "ArrowUpRight",
      size: 16,
      strokeWidth: 1.75
    })))));
  }
  function LandingPage({
    onNavigate
  }) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Hero, {
      onNavigate: onNavigate
    }), /*#__PURE__*/React.createElement(IndexGrid, {
      onNavigate: onNavigate
    }), /*#__PURE__*/React.createElement(CTA, {
      onNavigate: onNavigate
    }));
  }
  window.VALandingPage = LandingPage;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ventureai/LandingPage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ventureai/Masthead.jsx
try { (() => {
/* Masthead — sticky editorial header with blur. Uses DS NavLink + Button. */
(function () {
  const {
    NavLink,
    Button
  } = window.VentureAIDesignSystem_c6e9d5;
  function Masthead({
    route,
    onNavigate
  }) {
    const onWorkspace = route === "workspace";
    return /*#__PURE__*/React.createElement("header", {
      style: {
        position: "sticky",
        top: 0,
        zIndex: 40,
        borderBottom: "1px solid var(--ink-10)",
        background: "var(--masthead-bg)",
        backdropFilter: "blur(var(--masthead-blur))",
        WebkitBackdropFilter: "blur(var(--masthead-blur))"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        maxWidth: "var(--container-max)",
        margin: "0 auto",
        padding: "0 var(--container-pad)",
        height: 64,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between"
      }
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => {
        e.preventDefault();
        onNavigate("landing");
      },
      style: {
        display: "flex",
        alignItems: "baseline",
        gap: 12,
        textDecoration: "none",
        color: "var(--ink)"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 18,
        letterSpacing: "var(--tracking-tightest)"
      }
    }, "VentureAI"), /*#__PURE__*/React.createElement("span", {
      className: "va-label-mono",
      style: {
        display: "none"
      }
    }, "Investment Copilot")), /*#__PURE__*/React.createElement("nav", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 4
      }
    }, /*#__PURE__*/React.createElement(NavLink, {
      href: "#",
      active: !onWorkspace,
      onClick: e => {
        e.preventDefault();
        onNavigate("landing");
      }
    }, "Overview"), /*#__PURE__*/React.createElement(NavLink, {
      href: "#",
      active: onWorkspace,
      onClick: e => {
        e.preventDefault();
        onNavigate("workspace");
      }
    }, "Workspace"), /*#__PURE__*/React.createElement(Button, {
      size: "sm",
      style: {
        marginLeft: 8
      },
      onClick: () => onNavigate("workspace")
    }, "Launch", /*#__PURE__*/React.createElement(VAIcon, {
      name: "ArrowUpRight",
      size: 14,
      strokeWidth: 1.75
    })))));
  }
  window.VAMasthead = Masthead;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ventureai/Masthead.jsx", error: String((e && e.message) || e) }); }

// ui_kits/ventureai/data.js
try { (() => {
/* VentureAI agent registry + mock data — mirrors ventureai/backend & config/agents.ts. */
window.VA_AGENTS = [{
  id: "sourcing",
  code: "VA-01",
  name: "Deal Sourcing",
  role: "Intake & structuring",
  summary: "Turns a name, URL, or raw blurb into a structured startup profile with a first-pass conviction score.",
  capability: "Structured profile + 0–100 score",
  icon: "Crosshair",
  outputType: "startup_profile",
  isAvailable: true,
  field: {
    label: "Company signal",
    placeholder: "Paste a company name, website, or a few sentences describing the startup…",
    helper: "Anything works — a domain, a one-liner, or a pasted paragraph from a pitch deck."
  }
}, {
  id: "market",
  code: "VA-02",
  name: "Market Research",
  role: "Opportunity sizing",
  summary: "Sizes the TAM, reads the competitive landscape, and renders a verdict on market timing.",
  capability: "TAM, competitors, timing verdict",
  icon: "Globe2",
  outputType: "market_analysis",
  isAvailable: false
}, {
  id: "founder",
  code: "VA-03",
  name: "Founder Diligence",
  role: "Team assessment",
  summary: "Evaluates founder–market fit, team completeness, and prior exits — with the red flags left in.",
  capability: "Founder scorecard + flags",
  icon: "Users",
  outputType: "founder_analysis",
  isAvailable: false
}, {
  id: "financial",
  code: "VA-04",
  name: "Financial Analysis",
  role: "Model & unit economics",
  summary: "Pressure-tests the revenue model, unit economics, burn, and the path to profitability.",
  capability: "Unit economics + red flags",
  icon: "LineChart",
  outputType: "financial_analysis",
  isAvailable: false
}, {
  id: "bear",
  code: "VA-05",
  name: "Bear Case",
  role: "Adversarial review",
  summary: "Argues the other side — failure modes, fragilities, and the reasons this deal could break.",
  capability: "Structured failure modes",
  icon: "ShieldAlert",
  outputType: "bear_case",
  isAvailable: false
}, {
  id: "memo",
  code: "VA-06",
  name: "Investment Memo",
  role: "Synthesis & verdict",
  summary: "Synthesizes every agent into one committee-ready memo: a verdict, a score, and the next questions.",
  capability: "PASS · WATCH · INVEST verdict",
  icon: "FileText",
  outputType: "investment_memo",
  isAvailable: false
}];

/* Mock sourcing result — the Airbnb profile from ventureai/backend/mock_data.py. */
window.VA_MOCK_PROFILE = {
  company_name: "Airbnb",
  one_liner: "A marketplace for people to list, discover, and book unique accommodations around the world.",
  stage: "Seed",
  industry: "Travel / Marketplace",
  location: "San Francisco, CA",
  founders: ["Brian Chesky", "Joe Gebbia", "Nathan Blecharczyk"],
  score: 88,
  summary: "Strong marketplace concept targeting the massive global travel market with unique peer-to-peer supply. Network effects create a durable moat; regulatory headwinds are real but manageable."
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/ventureai/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardTitle = __ds_scope.CardTitle;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.ScoreBadge = __ds_scope.ScoreBadge;

__ds_ns.StatusGlyph = __ds_scope.StatusGlyph;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Textarea = __ds_scope.Textarea;

__ds_ns.NavLink = __ds_scope.NavLink;

__ds_ns.AgentCell = __ds_scope.AgentCell;

})();
