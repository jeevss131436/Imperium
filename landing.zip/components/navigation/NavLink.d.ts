import * as React from "react";

export interface NavLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  /** Current page — renders full ink instead of muted. */
  active?: boolean;
}

/** Mono uppercase masthead link; muted → ink on hover/active. */
export function NavLink(props: NavLinkProps): JSX.Element;
