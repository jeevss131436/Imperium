import React from "react";

/**
 * NavLink — a mono uppercase masthead link. Active = full ink; inactive =
 * muted, brightening to ink on hover. Renders an <a>; pass `href`.
 */
export function NavLink({ active = false, href = "#", className = "", style = {}, children, ...props }) {
  const [hover, setHover] = React.useState(false);
  return (
    <a
      href={href}
      className={className}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-block",
        padding: "8px 12px",
        fontFamily: "var(--font-mono)",
        fontSize: "11px",
        textTransform: "uppercase",
        letterSpacing: "var(--tracking-wider)",
        textDecoration: "none",
        color: active ? "var(--ink)" : hover ? "var(--ink)" : "var(--muted-foreground)",
        transition: "color var(--dur-base) var(--ease-out)",
        ...style,
      }}
      {...props}
    >
      {children}
    </a>
  );
}
