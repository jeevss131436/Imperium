A mono uppercase masthead link. Active renders full ink; inactive is muted and brightens to ink on hover.

```jsx
<NavLink href="/" active>Overview</NavLink>
<NavLink href="/app">Workspace</NavLink>
```

Use in the sticky masthead nav. Pair with a solid `Button` for the primary "Launch" action.
