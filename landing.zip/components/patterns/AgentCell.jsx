import React from "react";
import { StatusGlyph } from "../data-display/StatusGlyph.jsx";

/**
 * AgentCell — the signature bento ledger cell. A numbered committee entry that
 * inverts to ink-on-paper on hover. Used on the landing index grid and as the
 * panel header device. Pass a Lucide icon node via `icon`.
 */
export function AgentCell({
  code,
  name,
  summary,
  capability,
  available = false,
  icon = null,
  className = "",
  style = {},
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const fg = hover ? "var(--paper)" : "var(--ink)";
  const muted = hover ? "rgba(0,0,0,0.6)" : "var(--muted-foreground)";

  return (
    <div
      className={className}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        position: "relative",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        gap: 40,
        background: hover ? "var(--ink)" : "var(--paper)",
        color: fg,
        padding: 32,
        minHeight: 280,
        boxSizing: "border-box",
        transition: "background var(--dur-base) var(--ease-out), color var(--dur-base) var(--ease-out)",
        ...style,
      }}
      {...props}
    >
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between" }}>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-xs)", letterSpacing: "var(--tracking-wider)", color: muted, transition: "color var(--dur-base) var(--ease-out)" }}>
          {code}
        </span>
        <span style={{ color: fg, display: "inline-flex" }}>{icon}</span>
      </div>

      <div>
        <div style={{ marginBottom: 16 }}>
          <StatusGlyph available={available} />
        </div>
        <h3 style={{ margin: 0, fontFamily: "var(--font-display)", fontSize: "var(--text-2xl)", fontWeight: "var(--weight-bold)", letterSpacing: "var(--tracking-tight)" }}>
          {name}
        </h3>
        {summary && (
          <p style={{ margin: "12px 0 0", fontFamily: "var(--font-sans)", fontSize: "var(--text-sm)", lineHeight: "var(--leading-relaxed)", color: muted, transition: "color var(--dur-base) var(--ease-out)" }}>
            {summary}
          </p>
        )}
        {capability && (
          <p style={{ margin: "20px 0 0", fontFamily: "var(--font-mono)", fontSize: "11px", textTransform: "uppercase", letterSpacing: "var(--tracking-wide)", color: fg, transition: "color var(--dur-base) var(--ease-out)" }}>
            {capability}
          </p>
        )}
      </div>
    </div>
  );
}
