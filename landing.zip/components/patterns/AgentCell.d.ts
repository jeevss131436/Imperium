import * as React from "react";

/**
 * @startingPoint section="Patterns" subtitle="Bento ledger cell that inverts on hover" viewport="700x320"
 */
export interface AgentCellProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Ledger code, e.g. "VA-01". */
  code: string;
  /** Agent name. */
  name: string;
  /** One-line editorial summary. */
  summary?: string;
  /** Mono uppercase capability line — what the agent produces. */
  capability?: string;
  /** Backend availability — drives the StatusGlyph. */
  available?: boolean;
  /** A Lucide icon node (e.g. `<Crosshair />`). */
  icon?: React.ReactNode;
}

/** The signature bento committee cell; inverts to ink-on-paper on hover. */
export function AgentCell(props: AgentCellProps): JSX.Element;
