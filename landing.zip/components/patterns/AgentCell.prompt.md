The signature bento ledger cell — a numbered committee entry that inverts to ink-on-paper on hover. Composes `StatusGlyph`. Use it to build the landing index grid and workspace panel headers.

```jsx
<AgentCell
  code="VA-01"
  name="Deal Sourcing"
  summary="Turns a name or URL into a structured profile with a first-pass conviction score."
  capability="Structured profile + 0–100 score"
  available
  icon={<Crosshair strokeWidth={1.4} />}
/>
```

Lay cells in a `grid` with `1px` gaps over an `ink/10` background so the hairline rules show between them. Pass Lucide icons only — never emoji.
