The bordered multi-line intake box — sharp corners, hairline border brightening to full ink on focus, no resize handle. This is the primary "company signal" input in the workspace.

```jsx
<Textarea placeholder="Paste a company name, website, or a few sentences…" />
```

Supports ⌘/Ctrl+Enter submit via your own `onKeyDown`. Pair with a `.va-label-mono` label and a helper line in `--text-muted`.
