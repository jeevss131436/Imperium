import * as React from "react";

export interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {}

/** A bottom-ruled single-line field. Hairline underline brightens on focus. */
export function Input(props: InputProps): JSX.Element;
