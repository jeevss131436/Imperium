import * as React from "react";

export interface TextareaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {}

/** The bordered intake box. Hairline border brightens to full ink on focus; no resize handle. */
export function Textarea(props: TextareaProps): JSX.Element;
