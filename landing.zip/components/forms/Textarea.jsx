import React from "react";

/**
 * Textarea — the bordered intake box. Sharp corners, hairline border that
 * brightens to full ink on focus. No resize handle (matches the codebase).
 */
export function Textarea({ className = "", style = {}, disabled = false, ...props }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <textarea
      className={className}
      disabled={disabled}
      onFocus={(e) => { setFocus(true); props.onFocus?.(e); }}
      onBlur={(e) => { setFocus(false); props.onBlur?.(e); }}
      style={{
        minHeight: 140,
        width: "100%",
        boxSizing: "border-box",
        resize: "none",
        border: `1px solid ${focus ? "var(--ink)" : "var(--ink-20)"}`,
        background: "transparent",
        padding: 16,
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--ink)",
        outline: "none",
        borderRadius: 0,
        opacity: disabled ? 0.4 : 1,
        transition: "border-color var(--dur-base) var(--ease-out)",
        ...style,
      }}
      {...props}
    />
  );
}
