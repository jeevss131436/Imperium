import React from "react";

/**
 * Button — the strict monochrome control. No tints; contrast does the work.
 * Mono uppercase label, wide tracking, sharp corners, 300ms editorial ease.
 */
const SIZES = {
  sm: { height: 36, padding: "0 16px", fontSize: 12 },
  md: { height: 44, padding: "0 24px", fontSize: 12 },
  lg: { height: 56, padding: "0 36px", fontSize: 13 },
  icon: { height: 40, width: 40, padding: 0, fontSize: 12 },
};

export function Button({
  variant = "solid",
  size = "md",
  disabled = false,
  className = "",
  style = {},
  children,
  ...props
}) {
  const [hover, setHover] = React.useState(false);
  const sz = SIZES[size] || SIZES.md;

  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    whiteSpace: "nowrap",
    fontFamily: "var(--font-mono)",
    textTransform: "uppercase",
    letterSpacing: "var(--tracking-wider)",
    border: "1px solid transparent",
    borderRadius: 0,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    pointerEvents: disabled ? "none" : "auto",
    transition: "all var(--dur-base) var(--ease-out)",
    height: sz.height,
    width: sz.width,
    padding: sz.padding,
    fontSize: sz.fontSize,
    ...variantStyle(variant, hover),
    ...style,
  };

  return (
    <button
      className={className}
      style={base}
      disabled={disabled}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      {...props}
    >
      {children}
    </button>
  );
}

function variantStyle(variant, hover) {
  switch (variant) {
    case "outline":
      return hover
        ? { background: "var(--ink)", color: "var(--paper)", borderColor: "var(--ink)" }
        : { background: "transparent", color: "var(--ink)", borderColor: "var(--ink-20)" };
    case "ghost":
      return {
        background: hover ? "var(--ink-06)" : "transparent",
        color: "var(--ink)",
        borderColor: "transparent",
      };
    case "inverted":
      return { background: hover ? "var(--ink-85)" : "var(--paper)", color: "var(--ink)" };
    case "solid":
    default:
      return { background: hover ? "var(--ink-85)" : "var(--ink)", color: "var(--paper)" };
  }
}
