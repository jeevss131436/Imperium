import * as React from "react";

/**
 * @startingPoint section="Forms" subtitle="Monochrome button, four variants" viewport="700x160"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual treatment. `solid` is the default inverted-fill action. */
  variant?: "solid" | "outline" | "ghost" | "inverted";
  /** Control height / padding. `icon` is a 40×40 square. */
  size?: "sm" | "md" | "lg" | "icon";
}

export function Button(props: ButtonProps): JSX.Element;
