import React from "react";

/**
 * Input — a single-line field as a bottom-ruled ledger line.
 * No box; just a hairline underline that brightens to full ink on focus.
 */
export function Input({ className = "", style = {}, disabled = false, ...props }) {
  const [focus, setFocus] = React.useState(false);
  return (
    <input
      className={className}
      disabled={disabled}
      onFocus={(e) => { setFocus(true); props.onFocus?.(e); }}
      onBlur={(e) => { setFocus(false); props.onBlur?.(e); }}
      style={{
        height: 48,
        width: "100%",
        boxSizing: "border-box",
        border: "none",
        borderBottom: `1px solid ${focus ? "var(--ink)" : "var(--ink-20)"}`,
        background: "transparent",
        padding: "8px 0",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        color: "var(--ink)",
        outline: "none",
        borderRadius: 0,
        opacity: disabled ? 0.4 : 1,
        transition: "border-color var(--dur-base) var(--ease-out)",
        ...style,
      }}
      {...props}
    />
  );
}
