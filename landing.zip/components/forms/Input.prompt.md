A bottom-ruled single-line text field — no box, just a hairline underline that brightens to full ink on focus. Use for short inputs (names, URLs, search).

```jsx
<Input placeholder="Company name" />
<Input type="url" placeholder="https://" defaultValue="" />
```

Pairs with a mono `.va-label-mono` eyebrow above it. For multi-line, use `Textarea`.
