The monochrome action control — mono uppercase label, sharp corners, no color. Use for any primary/secondary action across landing and workspace.

```jsx
<Button variant="solid" size="lg">Run agent</Button>
<Button variant="outline">Open the workspace</Button>
<Button variant="ghost" size="sm">Cancel</Button>
<Button variant="inverted">On a dark panel</Button>
<Button disabled>Locked</Button>
```

Variants: `solid` (default, ink fill on paper text), `outline` (hairline border that fills to ink on hover), `ghost` (faint wash on hover), `inverted` (paper fill — for use inside ink/black panels). Sizes: `sm`, `md` (default), `lg`, `icon`. Pair with a Lucide icon (e.g. `<ArrowRight />`) as a child; never an emoji.
