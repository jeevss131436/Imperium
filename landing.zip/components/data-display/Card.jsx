import React from "react";

/**
 * Card — a sharp-cornered container bounded by a hairline. The Swiss grid has
 * no soft edges and no drop shadows. Compose with CardHeader / CardTitle /
 * CardContent, or drop children in directly.
 */
export function Card({ className = "", style = {}, children, ...props }) {
  return (
    <div
      className={className}
      style={{
        border: "1px solid var(--ink-12)",
        background: "var(--surface-card)",
        color: "var(--text-primary)",
        borderRadius: 0,
        ...style,
      }}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardHeader({ style = {}, children, ...props }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6, padding: 24, ...style }} {...props}>
      {children}
    </div>
  );
}

export function CardTitle({ style = {}, children, ...props }) {
  return (
    <div
      style={{
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-xl)",
        fontWeight: "var(--weight-bold)",
        lineHeight: "var(--leading-tight)",
        letterSpacing: "var(--tracking-tight)",
        ...style,
      }}
      {...props}
    >
      {children}
    </div>
  );
}

export function CardContent({ style = {}, children, ...props }) {
  return (
    <div style={{ padding: 24, paddingTop: 0, ...style }} {...props}>
      {children}
    </div>
  );
}
