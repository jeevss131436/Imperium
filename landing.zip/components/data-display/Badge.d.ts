import * as React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** `outline` (hairline, default), `solid` (inverted ink fill), `ledger` (uppercase eyebrow chip). */
  variant?: "outline" | "solid" | "ledger";
}

/** A small mono chip bounded by a hairline — founder tags, metadata pills, eyebrow labels. */
export function Badge(props: BadgeProps): JSX.Element;
