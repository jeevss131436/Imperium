export interface ScoreBadgeProps {
  /** The 0–100 score numeral. */
  score?: number;
  /** Mono caption under the numeral. Default "Conviction". */
  label?: string;
  className?: string;
  style?: React.CSSProperties;
}

/** Inverted ink panel: a heavy display numeral over a mono ledger caption. */
export function ScoreBadge(props: ScoreBadgeProps): JSX.Element;
