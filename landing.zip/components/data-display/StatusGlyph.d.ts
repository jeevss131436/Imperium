/**
 * @startingPoint section="Data display" subtitle="Achromatic live/pending status glyph" viewport="700x120"
 */
export interface StatusGlyphProps {
  /** `true` = filled pulsing square + "Live"; `false` = hollow square + "Pending". */
  available?: boolean;
  /** Show the mono text label beside the glyph. Default true. */
  showLabel?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

export function StatusGlyph(props: StatusGlyphProps): JSX.Element;
