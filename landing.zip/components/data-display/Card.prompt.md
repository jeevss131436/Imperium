A sharp-cornered hairline container — the base surface for grouped content. No border radius, no drop shadow; depth comes from the 1px rule alone.

```jsx
<Card>
  <CardHeader>
    <CardTitle>Deal Sourcing</CardTitle>
  </CardHeader>
  <CardContent>Structured profile + 0–100 conviction score.</CardContent>
</Card>
```

For the bento ledger grid, lay bare `Card`s on an `ink/10` background with `1px` gaps so the hairline rules show through. Sub-parts (`CardHeader`, `CardTitle`, `CardContent`) are optional.
