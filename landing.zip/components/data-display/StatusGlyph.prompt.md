The signature status device — encodes availability with shape + motion, never color. Filled pulsing square = live, hollow square = pending. Inherits `currentColor`, so it inverts on hover/ink panels for free.

```jsx
<StatusGlyph available />
<StatusGlyph available={false} />
<StatusGlyph available showLabel={false} />
```

Use on agent cards, the workspace index, and panel headers. Never substitute a colored dot — the whole system is achromatic by design.
