The conviction-score block — a heavy display numeral over a mono ledger caption on an inverted ink panel. Anchors a startup profile or memo result.

```jsx
<ScoreBadge score={88} label="Conviction" />
<ScoreBadge score={82} label="Overall" />
```

Sits flush against the profile header (no gap) with a hairline dividing it from the company name. Keep the label short and uppercase.
