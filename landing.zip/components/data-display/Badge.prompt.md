A small mono chip bounded by a hairline — founder name tags, metadata pills, and uppercase eyebrow labels.

```jsx
<Badge>Brian Chesky</Badge>
<Badge variant="solid">INVEST</Badge>
<Badge variant="ledger">Seed</Badge>
```

Variants: `outline` (hairline default), `solid` (inverted ink fill — verdicts), `ledger` (wide-tracked uppercase eyebrow). Sharp corners only.
