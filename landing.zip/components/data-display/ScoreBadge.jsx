import React from "react";

/**
 * ScoreBadge — the conviction score block. A heavy display numeral over a
 * mono ledger caption, on an inverted ink panel. The signature result device.
 */
export function ScoreBadge({ score = 0, label = "Conviction", className = "", style = {} }) {
  return (
    <div
      className={className}
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        background: "var(--ink)",
        color: "var(--paper)",
        padding: "24px 28px",
        borderRadius: 0,
        ...style,
      }}
    >
      <span
        style={{
          fontFamily: "var(--font-display)",
          fontSize: "3rem",
          fontWeight: "var(--weight-bold)",
          lineHeight: 1,
          letterSpacing: "var(--tracking-tightest)",
        }}
      >
        {score}
      </span>
      <span
        style={{
          marginTop: 8,
          fontFamily: "var(--font-mono)",
          fontSize: "var(--text-3xs)",
          textTransform: "uppercase",
          letterSpacing: "var(--tracking-ledger)",
          color: "var(--ink-60)",
        }}
      >
        {label}
      </span>
    </div>
  );
}
