import React from "react";

/**
 * StatusGlyph — the signature availability device. Shape + motion only,
 * never color: a filled, pulsing square = live; a hollow square = pending.
 * Drawn in currentColor so it inverts automatically on dark/hover panels.
 */
export function StatusGlyph({ available = false, showLabel = true, className = "", style = {} }) {
  return (
    <span
      className={className}
      style={{ display: "inline-flex", alignItems: "center", gap: 8, ...style }}
    >
      <span
        aria-hidden
        style={{
          height: 8,
          width: 8,
          background: available ? "currentColor" : "transparent",
          border: available ? "none" : "1px solid currentColor",
          opacity: available ? 1 : 0.5,
          animation: available ? "va-pulse-dot 1.8s ease-in-out infinite" : "none",
        }}
      />
      {showLabel && (
        <span
          style={{
            fontFamily: "var(--font-mono)",
            fontSize: "var(--text-2xs)",
            textTransform: "uppercase",
            letterSpacing: "var(--tracking-ledger)",
            opacity: 0.7,
          }}
        >
          {available ? "Live" : "Pending"}
        </span>
      )}
    </span>
  );
}
