import React from "react";

/**
 * Badge — a small mono chip bounded by a hairline (founder tags, metadata
 * pills). Use `solid` for an inverted ink fill, `outline` for the hairline
 * default, `ledger` for an uppercase wide-tracked eyebrow chip.
 */
export function Badge({ variant = "outline", className = "", style = {}, children, ...props }) {
  const variants = {
    outline: { border: "1px solid var(--ink-20)", background: "transparent", color: "var(--ink)", letterSpacing: "0.04em" },
    solid: { border: "1px solid var(--ink)", background: "var(--ink)", color: "var(--paper)", letterSpacing: "0.04em" },
    ledger: { border: "1px solid var(--ink-15)", background: "transparent", color: "var(--muted-foreground)", textTransform: "uppercase", letterSpacing: "var(--tracking-wide)" },
  };
  return (
    <span
      className={className}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "4px 12px",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-xs)",
        borderRadius: 0,
        whiteSpace: "nowrap",
        ...variants[variant],
        ...style,
      }}
      {...props}
    >
      {children}
    </span>
  );
}
