import * as React from "react";

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {}

/** Sharp-cornered hairline container. No radius, no drop shadow. */
export function Card(props: CardProps): JSX.Element;
export function CardHeader(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
export function CardTitle(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
export function CardContent(props: React.HTMLAttributes<HTMLDivElement>): JSX.Element;
