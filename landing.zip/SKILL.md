---
name: ventureai-design
description: Use this skill to generate well-branded interfaces and assets for VentureAI (the copilot for high-conviction venture capital), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Quick reference

- **Aesthetic:** strict achromatic, editorial "deal ledger". Pure black ground (`--paper` #000), white figure (`--ink` #fff), the whole gray ramp is white-at-opacity. No accent hue, no gradients, no shadows, zero border-radius.
- **Type:** Nunito (display + body, weight carries hierarchy, set tight at -0.045em, italic-medium for emphasis) + IBM Plex Mono (uppercase ledger labels/codes/buttons at 0.28em tracking). Both Google Fonts.
- **Icons:** Lucide, stroke only, weight 1.3–1.75, `currentColor`. No emoji.
- **Signature moves:** hairline grid (cells on `--ink-10` with 1px gaps), full black↔white inversion on hover (300ms, `cubic-bezier(0.16,1,0.3,1)`), status by shape+motion (filled pulsing square = live, hollow = pending) never by color.
- **Voice:** terse, high-conviction analyst. Sentence case prose, UPPERCASE mono labels. No emoji, no marketing hype. The "committee / ledger / verdict" metaphor is load-bearing.

## Files
- `styles.css` + `tokens/` — link `styles.css`, use the CSS custom properties.
- `assets/icons.js` — `<VAIcon name="Crosshair" strokeWidth={1.4} />` shim over Lucide UMD for plain-script contexts.
- `components/` — Button, Input, Textarea, Card, Badge, ScoreBadge, StatusGlyph, NavLink, AgentCell.
- `ui_kits/ventureai/` — interactive landing + workspace recreation.
