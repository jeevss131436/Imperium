# VentureAI — Design System

**VentureAI** is the copilot for high-conviction venture capital: a committee of
specialist AI agents that source, diligence, and stress-test a deal before an
investor ever takes the meeting. Rather than one chat reply, it simulates a real
VC firm's process — six numbered agents, one pipeline, intake to verdict.

This design system captures VentureAI's house style: a **strict achromatic,
editorial "deal-ledger" aesthetic** — pure black ground, white type, monospace
ledger labels, hairline rules, and sharp Swiss corners. Status is communicated
with shape and motion, never color.

> **The product** — six agents in pipeline order:
> `VA-01 Deal Sourcing` · `VA-02 Market Research` · `VA-03 Founder Diligence` ·
> `VA-04 Financial Analysis` · `VA-05 Bear Case` · `VA-06 Investment Memo`.
> Only Deal Sourcing is wired to the backend today; the rest render an elegant
> "deployment pending" state.

---

## Sources

This system was reverse-engineered from the VentureAI codebase and repos. If you
have access, explore them to build more faithfully:

- **Codebase (source of truth):** `ventureai/` — React 18 + TypeScript + Vite
  frontend (`ventureai/frontend/src`), FastAPI backend (`ventureai/backend`).
- **GitHub:** [`jeevss131436/Imperium`](https://github.com/jeevss131436/Imperium)
  — "Agentic AI Workflows for Venture Capitalists" (contains the same
  `ventureai/` tree, a dev plan, and a project spec PDF).

Original stack: React, Tailwind CSS, Framer Motion, **Lucide React** icons.
The frontend's own design notes live in `ventureai/frontend/README.md`.

---

## Content fundamentals

How VentureAI writes. The voice is that of a **terse, confident investment
analyst** — editorial, declarative, never chatty.

- **Tone:** High-conviction and restrained. Short, weighted statements with a
  full stop. *"Bring a deal. Leave with a verdict."* · *"Each renders its own
  verdict; you keep every one of them."*
- **Casing:** Sentence case for body and headlines. **UPPERCASE only for mono
  ledger labels** (eyebrows, codes, button text) at very wide tracking —
  e.g. `VENTUREAI — INDEX OF AGENTS`, `ENTER THE WORKSPACE`, `VA-01 · INTAKE & STRUCTURING`.
- **Person:** Mostly impersonal/system-voiced ("Awaiting input", "Run the
  committee"). Second person for the user's benefit ("you keep every one of
  them", "before you ever take the meeting"). Rarely first person.
- **The committee metaphor is load-bearing:** agents are "numbered entries in
  the deal ledger", outputs are "verdicts" and "memos", the order is "the
  pipeline order — intake to verdict". Lean into it.
- **Numerals:** Agents are coded `VA-01`…`VA-06`. Scores are bare integers
  `0–100`. Verdicts are uppercase words: `PASS · WATCH · INVEST`.
- **Empty / pending states are written with dignity**, never apologetic:
  *"{Agent} isn't online yet. The logic exists in the backend, but this agent
  still needs its runtime and credentials before it can take input."*
- **No emoji. Ever.** No exclamatory marketing copy, no "🚀 supercharge".
- **Disclaimers are plain:** *"A research copilot. Not investment advice. Every
  agent output is a draft for the committee, not a decision."*

---

## Visual foundations

A single, uncompromising idea: **a ledger printed in black and white.**

- **Color:** Strictly achromatic, dark-first. `--paper` `#000000` is the ground;
  `--ink` `#FFFFFF` is the figure. The *entire* neutral ramp is white at an
  opacity (`--ink-04` → `--ink-90`). Secondary text is `hsl(0 0% 66%)`. **There
  is no accent hue anywhere** — no AI purple, no neon, no gradients.
- **Type:** Editorial pairing carried by two families. **Nunito** does display
  *and* body — weight (300–900) carries the hierarchy, set tight
  (`-0.045em`) and heavy for headlines, with *italic medium* for emphasis
  (*"Venture conviction, at speed."*). **IBM Plex Mono** does every data label,
  agent code, button, and eyebrow, uppercased at `0.28em` "ledger" tracking.
- **Backgrounds:** Flat black. No imagery, no photography, no illustration, no
  texture — except one device: a faint 4%-opacity 45° **diagonal hatch** behind
  pending agents (reads as "under construction" without color).
- **Layout:** A 1320px centered container with generous 24px gutters and
  gallery-grade vertical rhythm (sections at 80–160px). The signature structure
  is a **hairline grid**: cells sit on an `--ink-10` background with `1px` gaps,
  so the gaps *become* the rules. Bento rhythm — the first/last cells span wide.
- **Corners:** **Zero radius.** Everything is sharp. The Swiss grid has no soft
  edges.
- **Borders & elevation:** **No drop shadows, ever.** Depth is implied with 1px
  hairlines (`--ink-12` cards, `--ink-20` controls, `--ink-15` rules) and
  `inset 0 0 0 1px` rings. Buttons use an inset ring on hover, not a shadow.
- **Hover states:** The signature move is **full inversion** — a paper cell flips
  to ink (black→white background, text inverts) over `300ms`. Solid buttons
  darken to `--ink-85`; outline buttons fill to ink; ghost buttons take a faint
  `--ink-06` wash; nav links brighten muted→ink.
- **Press / focus:** Focus is always visible — a 2px `--ink` ring offset 2px from
  the element on `--paper`. No scale-down on press.
- **Motion:** Restrained and editorial. One house easing:
  `cubic-bezier(0.16, 1, 0.3, 1)`. Two reveals: **rise** (hero, `opacity` +
  `translateY(24px)`, 0.8s, staggered) and **fade-up** (`translateY(12px)`,
  0.6s). One loop: **pulse-dot** (opacity 1→0.25, 1.8s) on the live status glyph
  and skeleton bars. No bounce, no spring overshoot. `prefers-reduced-motion`
  kills all of it.
- **Transparency / blur:** Used sparingly and only for the sticky masthead —
  `rgba(0,0,0,0.85)` with a `4px` backdrop blur. Content surfaces are opaque.
- **Status, not color:** A filled pulsing square = live; a hollow square =
  pending. Drawn in `currentColor` so it inverts for free.

---

## Iconography

- **Lucide React, exclusively.** The codebase imports `lucide-react`; the agent
  registry maps each agent to a Lucide icon: `Crosshair` (Sourcing), `Globe2`
  (Market), `Users` (Founder), `LineChart` (Financial), `ShieldAlert` (Bear),
  `FileText` (Memo). UI chrome uses `ArrowUpRight`, `ArrowRight`, `ArrowDown`,
  `Lock`, `Loader2`, `CircleAlert`, `MapPin`, `Globe`, `Layers`.
- **Stroke, never fill.** Icons are line icons at thin weights — `strokeWidth`
  `1.3`–`1.75` (lighter than Lucide's `2` default), matching the editorial
  hairline language. Always `currentColor`.
- **No emoji, no unicode glyphs as icons, no PNG icons.** The status device is a
  CSS square, not an icon.
- **How to render here:** Lucide is CDN-available, so this system links it from
  CDN (`lucide@0.424.0` UMD) and ships a tiny React shim, `assets/icons.js`,
  exposing `<VAIcon name="Crosshair" strokeWidth={1.4} />` for cards and UI kits
  (no `lucide-react` needed in a plain-script context). In a real React app,
  import from `lucide-react` directly.

---

## Index — what's in this system

**Root**
- `styles.css` — the entrypoint (import-only). Consumers link this one file.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css`.
- `assets/icons.js` — Lucide → React shim (`VAIcon`).
- `SKILL.md` — Agent-Skills-compatible entry for use in Claude Code.

**Components** (`window.VentureAIDesignSystem_c6e9d5.<Name>`)
- `components/forms/` — **Button** (solid/outline/ghost/inverted · sm/md/lg/icon), **Input**, **Textarea**
- `components/data-display/` — **Card** (+Header/Title/Content), **Badge** (outline/solid/ledger), **ScoreBadge**, **StatusGlyph**
- `components/navigation/` — **NavLink**
- `components/patterns/` — **AgentCell** (the signature bento ledger cell)

**Foundations** (`guidelines/*.card.html`) — color, type, spacing, border specimen cards shown in the Design System tab.

**UI kit** (`ui_kits/ventureai/`) — interactive recreation: the **landing page**
(hero → bento committee index → CTA) and the **deal workspace** (agent index +
live sourcing intake + result dossier + pending states). Open `index.html`.

---

## Using the tokens

Link the entrypoint and reference custom properties — never hard-code hex:

```html
<link rel="stylesheet" href="styles.css" />
```
```css
.thing {
  background: var(--paper);
  color: var(--ink);
  font-family: var(--font-display);
  letter-spacing: var(--tracking-tightest);
  border: 1px solid var(--ink-12);
  transition: all var(--dur-base) var(--ease-editorial);
}
```

---

## Caveats

- **Fonts load from Google Fonts** (Nunito + IBM Plex Mono) via `@import` in
  `tokens/fonts.css` — both match the codebase exactly, so no substitution was
  needed. If you want self-hosted binaries, drop the `.woff2` files in and swap
  the `@import` for `@font-face` rules.
- **No logo asset exists** in the codebase — the brand mark is the wordmark
  "VentureAI" set in Nunito 700 at `-0.045em`. There is no symbol/lockup to ship.
